import React, { useEffect, useMemo, useState } from 'react';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import type { User } from 'firebase/auth';
import {
  Bookmark,
  FileText,
  Film,
  FolderPlus,
  Globe,
  HardDrive,
  Image as ImageIcon,
  Layers,
  LayoutDashboard,
  Loader2,
  LogIn,
  LogOut,
  Menu,
  Moon,
  Plus,
  Search,
  Share2,
  Shield,
  Star,
  Sun,
  Trash2,
  X,
} from 'lucide-react';
import type {
  AnalyzedVideo,
  AnalyzeVideoResponse,
  ExtractedLink,
  InboxItemType,
  SitePage,
  SiteSettings,
  UserPrivateRecord,
  UserProfileRecord,
  VideoCollection,
  VideoPlatform,
} from './types/video';
import { auth } from './lib/firebase';
import { authorizedFetch, type ClientUsageQuota } from './lib/apiClient';
import {
  createFirestoreCollection,
  createFirestoreVideo,
  deleteFirestoreCollection,
  deleteFirestoreVideo,
  ensureUserProfile,
  loadGuestCollections,
  loadGuestVideos,
  saveGuestCollections,
  saveGuestVideos,
  subscribeOwnPrivateInfo,
  subscribeOwnUserProfile,
  subscribeUserCollections,
  subscribeUserVideos,
  toggleFirestoreFavorite,
  updateFirestoreVideoCollection,
  updateFirestoreVideoLinks,
  updateFirestoreVideoNotes,
  updateFirestoreVideoTags,
} from './lib/libraryStore';
import {
  deleteLocalMedia,
  formatBytes,
  getLocalMedia,
  getLocalMediaStats,
  saveLocalMedia,
} from './lib/localMediaStore';
import {
  checkUserIsAdmin,
  DEFAULT_SITE_SETTINGS,
  subscribePublishedPages,
  subscribeSiteSettings,
} from './lib/adminStore';
import { DEFAULT_SITE_PAGES, sanitizeHttpUrl } from './lib/pageDefaults';
import {
  extractUrlFromShareParams,
  generateSafeId,
  getItemType,
  PLATFORM_LABELS,
  SAVE_REASON_PRESETS,
} from './lib/videoUtils';
import { AdminDashboard } from './components/AdminDashboard';
import { AuthModal } from './components/AuthModal';
import { OfflineIndicator, PWAInstallButton } from './components/PWAControls';
import { ShareSetupModal } from './components/ShareSetupModal';
import { SitePageView } from './components/SitePageView';
import { UserDashboard } from './components/UserDashboard';
import { VideoInspector } from './components/VideoInspector';
import { VideoLibraryList } from './components/VideoLibraryList';
import { VideoSubmitPanel } from './components/VideoSubmitPanel';

type SidebarFilter =
  | { type: 'all' }
  | { type: 'favorites' }
  | { type: 'collection'; collectionId: string };

type ActiveView = 'library' | 'user-dashboard' | 'admin' | 'page';

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result || '');
      const commaIdx = result.indexOf(',');
      resolve(commaIdx >= 0 ? result.slice(commaIdx + 1) : result);
    };
    reader.onerror = () => reject(new Error('Failed to read selected file.'));
    reader.readAsDataURL(file);
  });
}

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [ownProfile, setOwnProfile] = useState<UserProfileRecord | null>(null);
  const [ownPrivateInfo, setOwnPrivateInfo] = useState<UserPrivateRecord | null>(null);

  const [videos, setVideos] = useState<AnalyzedVideo[]>(() => loadGuestVideos());
  const [collections, setCollections] = useState<VideoCollection[]>(() => loadGuestCollections());
  const [publishedPages, setPublishedPages] = useState<SitePage[]>([]);
  const [siteSettings, setSiteSettings] = useState<SiteSettings>(DEFAULT_SITE_SETTINGS);
  const [logoLoadError, setLogoLoadError] = useState(false);
  const [uploadedObjectUrls, setUploadedObjectUrls] = useState<Record<string, string>>({});
  const [localStats, setLocalStats] = useState<{ count: number; totalBytes: number }>({
    count: 0,
    totalBytes: 0,
  });

  const [activeView, setActiveView] = useState<ActiveView>('library');
  const [activePageSlug, setActivePageSlug] = useState<string>('terms-of-service');
  const [adminInitialEditPage, setAdminInitialEditPage] = useState<SitePage | null>(null);

  const [sidebarFilter, setSidebarFilter] = useState<SidebarFilter>({ type: 'all' });
  const [selectedItemType, setSelectedItemType] = useState<InboxItemType | 'all'>('all');
  const [selectedPlatform, setSelectedPlatform] = useState<VideoPlatform | 'all'>('all');
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const [selectedVideoId, setSelectedVideoId] = useState<string | null>(null);
  const [pendingSeekSeconds, setPendingSeekSeconds] = useState<number | null>(null);

  const [quickLinkInput, setQuickLinkInput] = useState('');
  const [quickSaveReason, setQuickSaveReason] = useState('');
  const [quickNoteInput, setQuickNoteInput] = useState('');
  const [isSubmitOpen, setIsSubmitOpen] = useState(false);
  const [submitInitialUrl, setSubmitInitialUrl] = useState('');
  const [submitInitialTitle, setSubmitInitialTitle] = useState('');
  const [submitInitialMode, setSubmitInitialMode] = useState<'link' | 'screenshot' | 'file'>('link');
  const [submitInitialFile, setSubmitInitialFile] = useState<File | null>(null);
  const [isIncomingShare, setIsIncomingShare] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analyzeError, setAnalyzeError] = useState<string | null>(null);
  const [usageQuota, setUsageQuota] = useState<ClientUsageQuota | null>(null);

  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isShareSetupOpen, setIsShareSetupOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [isAddingCollection, setIsAddingCollection] = useState(false);
  const [newCollectionName, setNewCollectionName] = useState('');

  const [isDark, setIsDark] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    const saved = localStorage.getItem('clipindex_theme');
    if (saved) return saved === 'dark';
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add('dark');
      localStorage.setItem('clipindex_theme', 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem('clipindex_theme', 'light');
    }
  }, [isDark]);

  // Firebase Auth listener
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (firebaseUser) => {
      setUser(firebaseUser);
      setAuthReady(true);
    });
    return unsub;
  }, []);

  // Admin role check
  useEffect(() => {
    let active = true;
    if (!user) {
      setIsAdmin(false);
      return;
    }
    void checkUserIsAdmin(user).then((adminStatus) => {
      if (active) setIsAdmin(adminStatus);
    });
    return () => {
      active = false;
    };
  }, [user, user?.emailVerified]);

  // Public published pages subscription (Terms of Service, Privacy Policy, custom pages)
  useEffect(() => {
    const unsub = subscribePublishedPages(setPublishedPages);
    return unsub;
  }, []);

  // Public site settings subscription (branding, favicon, metadata, Google verification, AI brain defaults)
  useEffect(() => {
    const unsub = subscribeSiteSettings((next) => {
      setLogoLoadError(false);
      setSiteSettings(next);
    });
    return unsub;
  }, []);

  // Synchronize document head metadata, favicon, verification meta tag, and Schema.org JSON-LD
  useEffect(() => {
    const titleText = siteSettings.metaTitle || `${siteSettings.siteName} — ${siteSettings.tagline}`;
    document.title = titleText;

    const upsertMeta = (attrName: 'name' | 'property', attrVal: string, content: string) => {
      let el = document.head.querySelector<HTMLMetaElement>(`meta[${attrName}="${attrVal}"]`);
      if (!content) {
        if (el) el.remove();
        return;
      }
      if (!el) {
        el = document.createElement('meta');
        el.setAttribute(attrName, attrVal);
        document.head.appendChild(el);
      }
      el.setAttribute('content', content);
    };

    const upsertLink = (relVal: string, href: string) => {
      let el = document.head.querySelector<HTMLLinkElement>(`link[rel="${relVal}"]`);
      if (!href) {
        if (el) el.remove();
        return;
      }
      if (!el) {
        el = document.createElement('link');
        el.setAttribute('rel', relVal);
        document.head.appendChild(el);
      }
      el.setAttribute('href', href);
    };

    upsertMeta('name', 'description', siteSettings.metaDescription);
    upsertMeta('property', 'og:title', titleText);
    upsertMeta('property', 'og:description', siteSettings.metaDescription);
    upsertMeta('property', 'og:site_name', siteSettings.siteName);
    upsertMeta('name', 'twitter:title', titleText);
    upsertMeta('name', 'twitter:description', siteSettings.metaDescription);
    upsertMeta('name', 'apple-mobile-web-app-title', siteSettings.siteName);
    upsertMeta('name', 'google-site-verification', siteSettings.googleSiteVerification);

    const safeOgImg = sanitizeHttpUrl(siteSettings.ogImageUrl);
    upsertMeta('property', 'og:image', safeOgImg);
    upsertMeta('name', 'twitter:image', safeOgImg);

    const safeCanonical = sanitizeHttpUrl(siteSettings.canonicalUrl) || window.location.origin;
    upsertLink('canonical', safeCanonical);

    const safeFavicon = sanitizeHttpUrl(siteSettings.faviconUrl);
    upsertLink('icon', safeFavicon || '/icon.svg');
    upsertLink('apple-touch-icon', safeFavicon || '/apple-touch-icon.png');

    let ldScript = document.head.querySelector<HTMLScriptElement>('#clipindex-jsonld');
    if (!ldScript) {
      ldScript = document.createElement('script');
      ldScript.id = 'clipindex-jsonld';
      ldScript.type = 'application/ld+json';
      document.head.appendChild(ldScript);
    }
    ldScript.textContent = JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'WebApplication',
      name: siteSettings.siteName,
      description: siteSettings.metaDescription,
      url: safeCanonical,
      applicationCategory: 'MultimediaApplication',
      operatingSystem: 'Any',
    });
  }, [siteSettings]);

  // Firestore real-time subscriptions when signed in and verified; localStorage when guest
  useEffect(() => {
    if (!authReady) return;
    if (!user || !user.emailVerified) {
      setOwnProfile(null);
      setOwnPrivateInfo(null);
      setVideos(loadGuestVideos());
      setCollections(loadGuestCollections());
      return;
    }

    void ensureUserProfile(user).catch(() => {});

    // Migrate any guest items created before sign-in into the user's cloud library once
    const guestVideos = loadGuestVideos();
    if (guestVideos.length > 0) {
      const migrate = async () => {
        for (const gv of guestVideos) {
          await createFirestoreVideo(
            user,
            {
              itemType: gv.itemType,
              url: gv.url,
              platform: gv.platform,
              title: gv.title,
              creator: gv.creator,
              thumbnailUrl: gv.thumbnailUrl,
              durationLabel: gv.durationLabel,
              category: gv.category,
              summary: gv.summary,
              tldrBullets: gv.tldrBullets,
              tags: gv.tags,
              segments: gv.segments,
              transcript: gv.transcript,
              links: gv.links || [],
              metadataSource: 'migrated',
            },
            '',
            {
              saveReason: gv.saveReason,
              notes: gv.notes,
              localMediaId: gv.localMediaId,
            }
          );
        }
        saveGuestVideos([]);
      };
      void migrate().catch(() => {});
    }

    const unsubProfile = subscribeOwnUserProfile(user.uid, setOwnProfile);
    const unsubPrivate = subscribeOwnPrivateInfo(user.uid, setOwnPrivateInfo);
    const unsubVideos = subscribeUserVideos(user.uid, setVideos);
    const unsubCollections = subscribeUserCollections(user.uid, setCollections);

    return () => {
      unsubProfile();
      unsubPrivate();
      unsubVideos();
      unsubCollections();
    };
  }, [authReady, user, user?.emailVerified]);

  // Merge Firestore published pages with built-in legal page defaults
  const displayPages = useMemo(() => {
    const map = new Map<string, SitePage>();
    for (const def of DEFAULT_SITE_PAGES) {
      map.set(def.slug, def);
    }
    for (const p of publishedPages) {
      map.set(p.slug, p);
    }
    return Array.from(map.values());
  }, [publishedPages]);

  const activeSitePage = useMemo(
    () =>
      displayPages.find((p) => p.slug === activePageSlug || p.id === activePageSlug) ||
      DEFAULT_SITE_PAGES[0],
    [displayPages, activePageSlug]
  );

  const openPageBySlug = (slug: string) => {
    setActivePageSlug(slug);
    setActiveView('page');
    setSelectedVideoId(null);
    setMobileMenuOpen(false);
  };

  // Hydrate local device screenshots & refresh IndexedDB usage stats
  useEffect(() => {
    let active = true;
    void getLocalMediaStats().then((stats) => {
      if (active) setLocalStats(stats);
    });

    const missingScreenshots = videos.filter(
      (v) =>
        getItemType(v) === 'screenshot' &&
        v.localMediaId &&
        !uploadedObjectUrls[v.id] &&
        !uploadedObjectUrls[v.localMediaId]
    );
    if (missingScreenshots.length === 0) return;

    void Promise.all(
      missingScreenshots.slice(0, 30).map(async (v) => {
        const key = v.localMediaId!;
        const rec = await getLocalMedia(key);
        if (rec?.blob) {
          return { key, url: URL.createObjectURL(rec.blob) };
        }
        return null;
      })
    ).then((loaded) => {
      if (!active) return;
      const updates: Record<string, string> = {};
      for (const item of loaded) {
        if (item) updates[item.key] = item.url;
      }
      if (Object.keys(updates).length > 0) {
        setUploadedObjectUrls((prev) => ({ ...prev, ...updates }));
      }
    });

    return () => {
      active = false;
    };
  }, [videos, uploadedObjectUrls]);

  // Global Ctrl+V screenshot paste when on library view
  useEffect(() => {
    if (isSubmitOpen || activeView !== 'library') return;
    const handleGlobalPaste = (e: ClipboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) {
        return;
      }
      const items = e.clipboardData?.items;
      if (!items) return;
      for (const item of items) {
        if (item.type.startsWith('image/')) {
          const blob = item.getAsFile();
          if (blob) {
            e.preventDefault();
            const ext = item.type.split('/')[1] || 'png';
            const pastedFile = new File([blob], `screenshot_${Date.now()}.${ext}`, {
              type: item.type,
            });
            setAnalyzeError(null);
            setIsIncomingShare(false);
            setSubmitInitialMode('screenshot');
            setSubmitInitialFile(pastedFile);
            setIsSubmitOpen(true);
            break;
          }
        }
      }
    };
    window.addEventListener('paste', handleGlobalPaste);
    return () => window.removeEventListener('paste', handleGlobalPaste);
  }, [isSubmitOpen, activeView]);

  const refreshUsageQuota = () => {
    void authorizedFetch('/api/usage')
      .then((r) => (r.ok ? r.json() : null))
      .then((data: ClientUsageQuota | null) => {
        if (data && data.analyze) setUsageQuota(data);
      })
      .catch(() => {});
  };

  useEffect(() => {
    if (!authReady) return;
    refreshUsageQuota();
  }, [authReady, user?.uid, user?.emailVerified]);

  const handleAnalyzeUrl = async (params: {
    rawInput: string;
    title?: string;
    customFocus?: string;
    saveReason?: string;
    notes?: string;
    collectionId?: string;
    modeHint?: 'auto' | 'video' | 'link';
  }) => {
    setAnalyzeError(null);
    setIsAnalyzing(true);
    try {
      const res = await authorizedFetch('/api/analyze-video', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rawShareText: params.rawInput,
          title: params.title,
          customFocus: params.customFocus,
          saveReason: params.saveReason,
          userNote: params.notes,
          modeHint: params.modeHint || 'auto',
          aiSettings: {
            depth: siteSettings.aiDefaultDepth,
            language: siteSettings.aiDefaultLanguage,
            customInstruction: siteSettings.aiCustomInstruction,
          },
        }),
      });
      const data = (await res.json()) as AnalyzeVideoResponse & { error?: string };
      if (!res.ok) {
        throw new Error(data.error || 'Failed to analyze shared link.');
      }

      const targetCollectionId =
        params.collectionId ||
        (sidebarFilter.type === 'collection' ? sidebarFilter.collectionId : '');

      let createdId: string;
      if (user && user.emailVerified) {
        createdId = await createFirestoreVideo(user, data, targetCollectionId, {
          saveReason: params.saveReason,
          notes: params.notes,
        });
      } else {
        createdId = generateSafeId('vid');
        const now = Date.now();
        const guestVideo: AnalyzedVideo = {
          id: createdId,
          ownerId: 'guest',
          itemType: getItemType({ itemType: data.itemType, platform: data.platform }),
          url: data.url,
          platform: data.platform,
          title: data.title,
          creator: data.creator,
          thumbnailUrl: data.thumbnailUrl,
          durationLabel: data.durationLabel,
          category: data.category,
          collectionId: targetCollectionId,
          isFavorite: false,
          saveReason: params.saveReason?.trim() || '',
          summary: data.summary,
          tldrBullets: data.tldrBullets,
          tags: data.tags,
          segments: data.segments,
          transcript: data.transcript,
          links: data.links || [],
          notes: params.notes?.trim() || '',
          createdAtMs: now,
          updatedAtMs: now,
        };
        const updated = [guestVideo, ...videos];
        setVideos(updated);
        saveGuestVideos(updated);
      }

      setQuickLinkInput('');
      setQuickSaveReason('');
      setQuickNoteInput('');
      setIsSubmitOpen(false);
      setIsIncomingShare(false);
      setSubmitInitialUrl('');
      setSubmitInitialTitle('');
      setSubmitInitialFile(null);
      setActiveView('library');
      setSelectedVideoId(createdId);
      setPendingSeekSeconds(null);
    } catch (err) {
      setAnalyzeError(err instanceof Error ? err.message : 'Unable to analyze item.');
    } finally {
      setIsAnalyzing(false);
      refreshUsageQuota();
    }
  };

  const handleAnalyzeFile = async (params: {
    file: File;
    title?: string;
    customFocus?: string;
    saveReason?: string;
    notes?: string;
    collectionId?: string;
  }) => {
    setAnalyzeError(null);
    setIsAnalyzing(true);
    try {
      const base64 = await fileToBase64(params.file);
      const isImage = params.file.type.startsWith('image/');
      const localMediaId = generateSafeId('med');

      const res = await authorizedFetch('/api/analyze-video', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: params.title,
          customFocus: params.customFocus,
          saveReason: params.saveReason,
          userNote: params.notes,
          fileData: {
            mimeType: params.file.type || (isImage ? 'image/png' : 'video/mp4'),
            base64,
            fileName: params.file.name,
          },
          aiSettings: {
            depth: siteSettings.aiDefaultDepth,
            language: siteSettings.aiDefaultLanguage,
            customInstruction: siteSettings.aiCustomInstruction,
          },
        }),
      });
      const data = (await res.json()) as AnalyzeVideoResponse & { error?: string };
      if (!res.ok) {
        throw new Error(data.error || 'Failed to analyze uploaded media.');
      }

      // Store binary media strictly on user's local device (IndexedDB), never in Firestore
      const resolvedItemType: InboxItemType = isImage ? 'screenshot' : 'video';
      await saveLocalMedia(localMediaId, params.file, {
        fileName: params.file.name,
        mimeType: params.file.type || (isImage ? 'image/png' : 'video/mp4'),
        itemType: resolvedItemType,
      });
      const previewUrl = URL.createObjectURL(params.file);
      const localRefUrl = `local://device/${localMediaId}`;
      const normalizedData: AnalyzeVideoResponse = {
        ...data,
        itemType: resolvedItemType,
        url: localRefUrl,
      };

      const targetCollectionId =
        params.collectionId ||
        (sidebarFilter.type === 'collection' ? sidebarFilter.collectionId : '');

      let createdId: string;
      if (user && user.emailVerified) {
        createdId = await createFirestoreVideo(user, normalizedData, targetCollectionId, {
          saveReason: params.saveReason,
          notes: params.notes,
          localMediaId,
        });
      } else {
        createdId = generateSafeId('vid');
        const now = Date.now();
        const guestVideo: AnalyzedVideo = {
          id: createdId,
          ownerId: 'guest',
          itemType: resolvedItemType,
          url: localRefUrl,
          platform: normalizedData.platform,
          title: normalizedData.title,
          creator: normalizedData.creator,
          thumbnailUrl: '',
          durationLabel: normalizedData.durationLabel,
          category: normalizedData.category,
          collectionId: targetCollectionId,
          isFavorite: false,
          saveReason: params.saveReason?.trim() || '',
          localMediaId,
          summary: normalizedData.summary,
          tldrBullets: normalizedData.tldrBullets,
          tags: normalizedData.tags,
          segments: normalizedData.segments,
          transcript: normalizedData.transcript,
          links: normalizedData.links || [],
          notes: params.notes?.trim() || '',
          createdAtMs: now,
          updatedAtMs: now,
        };
        const updated = [guestVideo, ...videos];
        setVideos(updated);
        saveGuestVideos(updated);
      }

      setUploadedObjectUrls((prev) => ({
        ...prev,
        [createdId]: previewUrl,
        [localMediaId]: previewUrl,
      }));
      void getLocalMediaStats().then(setLocalStats);
      setIsSubmitOpen(false);
      setIsIncomingShare(false);
      setSubmitInitialFile(null);
      setActiveView('library');
      setSelectedVideoId(createdId);
      setPendingSeekSeconds(null);
    } catch (err) {
      setAnalyzeError(err instanceof Error ? err.message : 'Unable to analyze uploaded media.');
    } finally {
      setIsAnalyzing(false);
      refreshUsageQuota();
    }
  };

  // Handle Web Share Target intake (?url=...&text=...&title=... or /share-target)
  // Opens pre-filled modal so user can add "Why I saved this" quick tag & note
  useEffect(() => {
    if (!authReady) return;
    const params = new URLSearchParams(window.location.search);
    const isShareRoute = window.location.pathname === '/share-target';
    if (isShareRoute || params.has('url') || params.has('text')) {
      const { url, title, text } = extractUrlFromShareParams(params);
      window.history.replaceState({}, document.title, '/');
      const incomingValue = url || text;
      if (incomingValue) {
        setAnalyzeError(null);
        setSubmitInitialMode('link');
        setSubmitInitialUrl(incomingValue);
        setSubmitInitialTitle(title);
        setIsIncomingShare(true);
        setIsSubmitOpen(true);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authReady]);

  const handleSignOut = async () => {
    try {
      await signOut(auth);
      setSelectedVideoId(null);
      setActiveView('library');
    } catch (err) {
      console.error('Sign out failed:', err);
    }
  };

  const handleCreateCollection = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newCollectionName.trim();
    if (!trimmed) return;

    if (user && user.emailVerified) {
      const newId = await createFirestoreCollection(user, trimmed);
      setSidebarFilter({ type: 'collection', collectionId: newId });
    } else {
      const now = Date.now();
      const col: VideoCollection = {
        id: generateSafeId('col'),
        ownerId: 'guest',
        name: trimmed.slice(0, 80),
        description: '',
        createdAtMs: now,
        updatedAtMs: now,
      };
      const updated = [...collections, col];
      setCollections(updated);
      saveGuestCollections(updated);
      setSidebarFilter({ type: 'collection', collectionId: col.id });
    }
    setActiveView('library');
    setNewCollectionName('');
    setIsAddingCollection(false);
  };

  const handleDeleteCollection = async (collectionId: string) => {
    if (user && user.emailVerified) {
      await deleteFirestoreCollection(user.uid, collectionId);
    } else {
      const updatedCols = collections.filter((c) => c.id !== collectionId);
      setCollections(updatedCols);
      saveGuestCollections(updatedCols);
      const updatedVids = videos.map((v) =>
        v.collectionId === collectionId ? { ...v, collectionId: '' } : v
      );
      setVideos(updatedVids);
      saveGuestVideos(updatedVids);
    }
    if (sidebarFilter.type === 'collection' && sidebarFilter.collectionId === collectionId) {
      setSidebarFilter({ type: 'all' });
    }
  };

  const handleToggleFavorite = async (video: AnalyzedVideo) => {
    const nextFav = !video.isFavorite;
    if (user && user.emailVerified) {
      await toggleFirestoreFavorite(user.uid, video.id, nextFav);
    } else {
      const updated = videos.map((v) =>
        v.id === video.id ? { ...v, isFavorite: nextFav, updatedAtMs: Date.now() } : v
      );
      setVideos(updated);
      saveGuestVideos(updated);
    }
  };

  const handleChangeCollection = async (videoId: string, collectionId: string) => {
    if (user && user.emailVerified) {
      await updateFirestoreVideoCollection(user.uid, videoId, collectionId);
    } else {
      const updated = videos.map((v) =>
        v.id === videoId ? { ...v, collectionId, updatedAtMs: Date.now() } : v
      );
      setVideos(updated);
      saveGuestVideos(updated);
    }
  };

  const handleUpdateTags = async (videoId: string, tags: string[]) => {
    if (user && user.emailVerified) {
      await updateFirestoreVideoTags(user.uid, videoId, tags);
    } else {
      const updated = videos.map((v) =>
        v.id === videoId ? { ...v, tags, updatedAtMs: Date.now() } : v
      );
      setVideos(updated);
      saveGuestVideos(updated);
    }
  };

  const handleUpdateNotes = async (videoId: string, notes: string, saveReason?: string) => {
    if (user && user.emailVerified) {
      await updateFirestoreVideoNotes(user.uid, videoId, notes, saveReason);
    } else {
      const updated = videos.map((v) =>
        v.id === videoId
          ? {
              ...v,
              notes,
              ...(typeof saveReason === 'string' ? { saveReason } : {}),
              updatedAtMs: Date.now(),
            }
          : v
      );
      setVideos(updated);
      saveGuestVideos(updated);
    }
  };

  const handleUpdateLinks = async (videoId: string, links: ExtractedLink[]) => {
    if (user && user.emailVerified) {
      await updateFirestoreVideoLinks(user.uid, videoId, links);
    } else {
      const updated = videos.map((v) =>
        v.id === videoId ? { ...v, links, updatedAtMs: Date.now() } : v
      );
      setVideos(updated);
      saveGuestVideos(updated);
    }
  };

  const handleDeleteVideo = async (videoId: string) => {
    const target = videos.find((v) => v.id === videoId);
    if (user && user.emailVerified) {
      await deleteFirestoreVideo(user.uid, videoId);
    } else {
      const updated = videos.filter((v) => v.id !== videoId);
      setVideos(updated);
      saveGuestVideos(updated);
    }
    await deleteLocalMedia(target?.localMediaId || videoId);
    void getLocalMediaStats().then(setLocalStats);
    if (selectedVideoId === videoId) {
      setSelectedVideoId(null);
    }
  };

  const topTags = useMemo(() => {
    const counts = new Map<string, number>();
    for (const v of videos) {
      for (const tag of v.tags) {
        counts.set(tag, (counts.get(tag) || 0) + 1);
      }
    }
    return Array.from(counts.entries())
      .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
      .slice(0, 14);
  }, [videos]);

  const filteredVideos = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return videos.filter((v) => {
      if (sidebarFilter.type === 'favorites' && !v.isFavorite) return false;
      if (sidebarFilter.type === 'collection' && v.collectionId !== sidebarFilter.collectionId) {
        return false;
      }
      if (selectedItemType !== 'all' && getItemType(v) !== selectedItemType) return false;
      if (selectedPlatform !== 'all' && v.platform !== selectedPlatform) return false;
      if (selectedTag && !v.tags.includes(selectedTag)) return false;
      if (!q) return true;

      const inBasic =
        v.title.toLowerCase().includes(q) ||
        v.creator.toLowerCase().includes(q) ||
        v.summary.toLowerCase().includes(q) ||
        v.category.toLowerCase().includes(q) ||
        (v.saveReason && v.saveReason.toLowerCase().includes(q)) ||
        v.tags.some((t) => t.includes(q)) ||
        v.notes.toLowerCase().includes(q);
      if (inBasic) return true;

      const inLinks = (v.links || []).some(
        (lnk) =>
          lnk.label.toLowerCase().includes(q) ||
          lnk.url.toLowerCase().includes(q) ||
          (lnk.context && lnk.context.toLowerCase().includes(q))
      );
      if (inLinks) return true;

      const inSegments = v.segments.some(
        (s) =>
          s.title.toLowerCase().includes(q) ||
          s.summary.toLowerCase().includes(q) ||
          (s.keyQuote && s.keyQuote.toLowerCase().includes(q))
      );
      if (inSegments) return true;

      return v.transcript.some((t) => t.text.toLowerCase().includes(q));
    });
  }, [videos, sidebarFilter, selectedItemType, selectedPlatform, selectedTag, searchQuery]);

  const selectedVideo = useMemo(
    () => videos.find((v) => v.id === selectedVideoId) || null,
    [videos, selectedVideoId]
  );

  const platformTabs: Array<{ id: VideoPlatform | 'all'; label: string }> = [
    { id: 'all', label: 'All Platforms' },
    { id: 'youtube', label: 'YouTube' },
    { id: 'tiktok', label: 'TikTok' },
    { id: 'instagram', label: 'Instagram' },
    { id: 'facebook', label: 'Facebook' },
    { id: 'web', label: 'Web Links' },
    { id: 'screenshot', label: 'Screenshots' },
    { id: 'upload', label: 'Local Clips' },
  ];

  const activeCollectionName =
    sidebarFilter.type === 'collection'
      ? collections.find((c) => c.id === sidebarFilter.collectionId)?.name
      : null;

  const sidebarContent = (
    <div className="flex flex-col h-full justify-between p-4 space-y-6">
      <div className="space-y-6 overflow-y-auto pr-1">
        {/* Universal Share Inbox Views */}
        <div className="space-y-1">
          <p className="px-2.5 text-xs font-medium text-slate-500 dark:text-slate-400 mb-2">
            Universal Share Inbox
          </p>
          <button
            type="button"
            onClick={() => {
              setActiveView('library');
              setSidebarFilter({ type: 'all' });
              setSelectedItemType('all');
              setSelectedVideoId(null);
              setMobileMenuOpen(false);
            }}
            className={`w-full flex items-center justify-between px-2.5 py-2 text-sm rounded-lg transition-colors ${
              activeView === 'library' && sidebarFilter.type === 'all' && selectedItemType === 'all'
                ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-medium'
                : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <Layers className="w-4 h-4" />
              All Saved Items
            </span>
            <span className="text-xs font-mono tabular-nums opacity-75">{videos.length}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveView('library');
              setSidebarFilter({ type: 'all' });
              setSelectedItemType('video');
              setSelectedVideoId(null);
              setMobileMenuOpen(false);
            }}
            className={`w-full flex items-center justify-between px-2.5 py-1.5 text-sm rounded-lg transition-colors ${
              activeView === 'library' && sidebarFilter.type === 'all' && selectedItemType === 'video'
                ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-medium'
                : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <Film className="w-4 h-4" />
              Videos
            </span>
            <span className="text-xs font-mono tabular-nums opacity-75">
              {videos.filter((v) => getItemType(v) === 'video').length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveView('library');
              setSidebarFilter({ type: 'all' });
              setSelectedItemType('screenshot');
              setSelectedVideoId(null);
              setMobileMenuOpen(false);
            }}
            className={`w-full flex items-center justify-between px-2.5 py-1.5 text-sm rounded-lg transition-colors ${
              activeView === 'library' && sidebarFilter.type === 'all' && selectedItemType === 'screenshot'
                ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-medium'
                : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <ImageIcon className="w-4 h-4" />
              Screenshots
            </span>
            <span className="text-xs font-mono tabular-nums opacity-75">
              {videos.filter((v) => getItemType(v) === 'screenshot').length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveView('library');
              setSidebarFilter({ type: 'all' });
              setSelectedItemType('link');
              setSelectedVideoId(null);
              setMobileMenuOpen(false);
            }}
            className={`w-full flex items-center justify-between px-2.5 py-1.5 text-sm rounded-lg transition-colors ${
              activeView === 'library' && sidebarFilter.type === 'all' && selectedItemType === 'link'
                ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-medium'
                : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <Globe className="w-4 h-4" />
              Web &amp; Product Links
            </span>
            <span className="text-xs font-mono tabular-nums opacity-75">
              {videos.filter((v) => getItemType(v) === 'link').length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveView('library');
              setSidebarFilter({ type: 'favorites' });
              setSelectedItemType('all');
              setSelectedVideoId(null);
              setMobileMenuOpen(false);
            }}
            className={`w-full flex items-center justify-between px-2.5 py-2 text-sm rounded-lg transition-colors ${
              activeView === 'library' && sidebarFilter.type === 'favorites'
                ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-medium'
                : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <Star className="w-4 h-4" />
              Favorites
            </span>
            <span className="text-xs font-mono tabular-nums opacity-75">
              {videos.filter((v) => v.isFavorite).length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => {
              setIsShareSetupOpen(true);
              setMobileMenuOpen(false);
            }}
            className="w-full flex items-center gap-2.5 px-2.5 py-2 text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70 rounded-lg transition-colors"
          >
            <Share2 className="w-4 h-4" />
            Share Sheet Setup
          </button>

          {localStats.count > 0 && (
            <div className="px-2.5 pt-1.5 flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400">
              <HardDrive className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">
                Device cache: {localStats.count} {localStats.count === 1 ? 'file' : 'files'} ({formatBytes(localStats.totalBytes)})
              </span>
            </div>
          )}
        </div>

        {/* Workspace Dashboards */}
        {user && (
          <div className="space-y-1 pt-4 border-t border-slate-200 dark:border-slate-800">
            <p className="px-2.5 text-xs font-medium text-slate-500 dark:text-slate-400 mb-2">
              Workspace
            </p>
            <button
              type="button"
              onClick={() => {
                setActiveView('user-dashboard');
                setSelectedVideoId(null);
                setMobileMenuOpen(false);
              }}
              className={`w-full flex items-center gap-2.5 px-2.5 py-2 text-sm rounded-lg transition-colors ${
                activeView === 'user-dashboard'
                  ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-medium'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              User Dashboard
            </button>

            {isAdmin && (
              <button
                type="button"
                onClick={() => {
                  setActiveView('admin');
                  setSelectedVideoId(null);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-2.5 px-2.5 py-2 text-sm rounded-lg transition-colors ${
                  activeView === 'admin'
                    ? 'bg-blue-600 text-white font-medium'
                    : 'text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/30'
                }`}
              >
                <Shield className="w-4 h-4" />
                Admin Console
              </button>
            )}
          </div>
        )}

        {/* Collections */}
        <div className="space-y-1.5 pt-4 border-t border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between px-2.5">
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Collections</p>
            <button
              type="button"
              onClick={() => setIsAddingCollection((v) => !v)}
              className="p-1 text-slate-500 hover:text-slate-900 dark:hover:text-slate-100 rounded"
              title="New collection"
              aria-label="New collection"
            >
              <FolderPlus className="w-3.5 h-3.5" />
            </button>
          </div>

          {isAddingCollection && (
            <form onSubmit={(e) => void handleCreateCollection(e)} className="px-2 py-1 space-y-2">
              <input
                type="text"
                value={newCollectionName}
                onChange={(e) => setNewCollectionName(e.target.value)}
                placeholder="Collection name..."
                autoFocus
                className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600/30"
              />
              <div className="flex items-center justify-end gap-1.5">
                <button
                  type="button"
                  onClick={() => setIsAddingCollection(false)}
                  className="px-2 py-1 text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-2.5 py-1 text-xs font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md"
                >
                  Create
                </button>
              </div>
            </form>
          )}

          {collections.length === 0 ? (
            <p className="px-2.5 py-1 text-xs text-slate-400 dark:text-slate-500">
              No collections yet
            </p>
          ) : (
            collections.map((col) => {
              const isSelected =
                activeView === 'library' &&
                sidebarFilter.type === 'collection' &&
                sidebarFilter.collectionId === col.id;
              const count = videos.filter((v) => v.collectionId === col.id).length;
              return (
                <div key={col.id} className="group flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => {
                      setActiveView('library');
                      setSidebarFilter({ type: 'collection', collectionId: col.id });
                      setSelectedVideoId(null);
                      setMobileMenuOpen(false);
                    }}
                    className={`flex-1 flex items-center justify-between px-2.5 py-1.5 text-sm rounded-lg transition-colors min-w-0 ${
                      isSelected
                        ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-medium'
                        : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70'
                    }`}
                  >
                    <span className="flex items-center gap-2 truncate">
                      <Bookmark className="w-3.5 h-3.5 shrink-0" />
                      <span className="truncate">{col.name}</span>
                    </span>
                    <span className="text-xs font-mono tabular-nums opacity-70 ml-2">{count}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => void handleDeleteCollection(col.id)}
                    title="Delete collection"
                    className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-red-600 transition-opacity"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })
          )}
        </div>

        {/* Searchable Tags Index */}
        {topTags.length > 0 && (
          <div className="space-y-2 pt-4 border-t border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between px-2.5">
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                Searchable Tags
              </p>
              {selectedTag && (
                <button
                  type="button"
                  onClick={() => setSelectedTag(null)}
                  className="text-xs text-blue-600 dark:text-blue-400 hover:underline"
                >
                  Clear
                </button>
              )}
            </div>
            <div className="px-2.5 flex flex-wrap gap-x-3 gap-y-1.5">
              {topTags.map(([tag, count]) => {
                const active = selectedTag === tag;
                return (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => {
                      setActiveView('library');
                      setSelectedTag(active ? null : tag);
                      setSelectedVideoId(null);
                      setMobileMenuOpen(false);
                    }}
                    className={`text-xs transition-colors whitespace-nowrap ${
                      active
                        ? 'font-semibold text-blue-600 dark:text-blue-400 underline underline-offset-4'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
                    }`}
                  >
                    #{tag}{' '}
                    <span className="font-mono tabular-nums text-[11px] opacity-60">{count}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Legal & Published Pages */}
        <div className="space-y-1 pt-4 border-t border-slate-200 dark:border-slate-800">
          <p className="px-2.5 text-xs font-medium text-slate-500 dark:text-slate-400 mb-1.5">
            Information
          </p>
          {displayPages.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => openPageBySlug(p.slug)}
              className={`w-full flex items-center gap-2 px-2.5 py-1.5 text-xs rounded-lg transition-colors text-left ${
                activeView === 'page' && activeSitePage.slug === p.slug
                  ? 'bg-slate-100 dark:bg-slate-800 font-medium text-slate-900 dark:text-slate-100'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 hover:bg-slate-100/70 dark:hover:bg-slate-800/50'
              }`}
            >
              <FileText className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">{p.title}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Account & Cloud Sync Footer */}
      <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-2.5">
        {user ? (
          <div className="flex items-center justify-between gap-2 px-1">
            <button
              type="button"
              onClick={() => {
                setActiveView('user-dashboard');
                setSelectedVideoId(null);
                setMobileMenuOpen(false);
              }}
              className="flex items-center gap-2.5 min-w-0 text-left group"
            >
              {user.photoURL ? (
                <img
                  src={user.photoURL}
                  alt={ownProfile?.displayName || user.displayName || 'Account'}
                  referrerPolicy="no-referrer"
                  className="w-7 h-7 rounded-full object-cover shrink-0"
                />
              ) : (
                <div className="w-7 h-7 rounded-full bg-blue-600 text-white text-xs font-semibold flex items-center justify-center shrink-0">
                  {(ownProfile?.displayName || user.displayName || user.email || 'U')
                    .slice(0, 1)
                    .toUpperCase()}
                </div>
              )}
              <div className="min-w-0">
                <p className="text-xs font-medium text-slate-900 dark:text-slate-100 truncate group-hover:text-blue-600 dark:group-hover:text-blue-400">
                  {ownProfile?.displayName || user.displayName || 'Account'}
                </p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                  {user.emailVerified
                    ? isAdmin
                      ? 'Admin · Cloud synced'
                      : 'Cloud synced'
                    : 'Verify email to sync'}
                </p>
              </div>
            </button>
            <button
              type="button"
              onClick={() => void handleSignOut()}
              title="Sign out"
              className="p-1.5 text-slate-500 hover:text-slate-900 dark:hover:text-slate-100 rounded-lg"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-snug px-1">
              Sign in or create an account to sync your library across devices.
            </p>
            <button
              type="button"
              onClick={() => setIsAuthModalOpen(true)}
              className="w-full inline-flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
            >
              <LogIn className="w-3.5 h-3.5" />
              Sign In / Sign Up
            </button>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      {/* Top Bar */}
      <header className="sticky top-0 z-30 h-14 border-b border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 backdrop-blur px-4 lg:px-6 flex items-center justify-between gap-6">
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => setMobileMenuOpen(true)}
            className="lg:hidden p-1.5 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
            aria-label="Open menu"
          >
            <Menu className="w-5 h-5" />
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveView('library');
              setSelectedVideoId(null);
              setSidebarFilter({ type: 'all' });
            }}
            className="inline-flex items-center gap-2.5 text-base font-bold tracking-tight text-slate-900 dark:text-slate-100 whitespace-nowrap shrink-0"
          >
            {sanitizeHttpUrl(siteSettings.logoUrl) && !logoLoadError ? (
              <img
                src={sanitizeHttpUrl(siteSettings.logoUrl)}
                alt={siteSettings.siteName}
                referrerPolicy="no-referrer"
                onError={() => setLogoLoadError(true)}
                className="h-7 max-w-[140px] object-contain"
              />
            ) : null}
            <span>{siteSettings.siteName}</span>
          </button>
        </div>

        {/* Cross-platform global search */}
        <div className="flex-1 max-w-xl hidden sm:block">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setActiveView('library');
                if (selectedVideoId) setSelectedVideoId(null);
              }}
              placeholder="Search videos, screenshots, links, why-saved notes, and tags..."
              className="w-full pl-9 pr-3 py-1.5 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/30 focus:border-blue-600"
            />
          </div>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          <PWAInstallButton />

          {!user ? (
            <button
              type="button"
              onClick={() => setIsAuthModalOpen(true)}
              className="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              Sign In
            </button>
          ) : (
            <button
              type="button"
              onClick={() => {
                setActiveView('user-dashboard');
                setSelectedVideoId(null);
              }}
              className="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              Dashboard
            </button>
          )}

          <button
            type="button"
            onClick={() => setIsDark((d) => !d)}
            aria-label={isDark ? 'Switch to light theme' : 'Switch to dark theme'}
            className="p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
          >
            {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          <button
            type="button"
            onClick={() => {
              setAnalyzeError(null);
              setIsIncomingShare(false);
              setSubmitInitialMode('link');
              setSubmitInitialUrl('');
              setSubmitInitialTitle('');
              setSubmitInitialFile(null);
              setIsSubmitOpen(true);
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            Save Item
          </button>
        </div>
      </header>

      {/* Main Workspace Shell */}
      <div className="flex-1 flex max-w-[1440px] w-full mx-auto">
        {/* Desktop Sidebar */}
        <aside className="hidden lg:block w-64 shrink-0 border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
          <div className="sticky top-14 h-[calc(100vh-3.5rem)]">{sidebarContent}</div>
        </aside>

        {/* Mobile Drawer Sidebar */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-50 lg:hidden flex">
            <div
              className="fixed inset-0 bg-black/40"
              onClick={() => setMobileMenuOpen(false)}
            />
            <aside className="relative w-72 max-w-[85vw] bg-white dark:bg-slate-900 h-full border-r border-slate-200 dark:border-slate-800 flex flex-col">
              <div className="flex items-center justify-between px-4 h-14 border-b border-slate-200 dark:border-slate-800">
                <span className="inline-flex items-center gap-2 text-base font-bold text-slate-900 dark:text-slate-100 truncate">
                  {sanitizeHttpUrl(siteSettings.logoUrl) && !logoLoadError ? (
                    <img
                      src={sanitizeHttpUrl(siteSettings.logoUrl)}
                      alt={siteSettings.siteName}
                      referrerPolicy="no-referrer"
                      className="h-6 max-w-[110px] object-contain shrink-0"
                    />
                  ) : null}
                  <span className="truncate">{siteSettings.siteName}</span>
                </span>
                <button
                  type="button"
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-1.5 text-slate-500 hover:text-slate-900 dark:hover:text-slate-100"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto">{sidebarContent}</div>
            </aside>
          </div>
        )}

        {/* Main Content Viewport */}
        <main className="flex-1 min-w-0 flex flex-col justify-between p-4 sm:p-6 lg:p-8 space-y-8">
          <div className="space-y-6">
            {user && !user.emailVerified && (
              <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 rounded-xl border border-amber-200 dark:border-amber-900/60 bg-amber-50 dark:bg-amber-950/30 text-xs text-amber-900 dark:text-amber-200">
                <span>
                  Your email address <strong>{user.email}</strong> is not verified yet. Verify it to activate cloud library sync and profile saving.
                </span>
                <button
                  type="button"
                  onClick={() => setIsAuthModalOpen(true)}
                  className="px-3 py-1.5 font-medium text-white bg-amber-600 hover:bg-amber-700 rounded-lg transition-colors whitespace-nowrap"
                >
                  Verify Email
                </button>
              </div>
            )}

            {/* Mobile search input */}
            <div className="sm:hidden relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setActiveView('library');
                  if (selectedVideoId) setSelectedVideoId(null);
                }}
                placeholder="Search videos, timestamps, tags..."
                className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/30"
              />
            </div>

            {activeView === 'user-dashboard' && user ? (
              <UserDashboard
                user={user}
                profile={ownProfile}
                privateInfo={ownPrivateInfo}
                videos={videos}
                collections={collections}
                isAdmin={isAdmin}
                onOpenLibrary={() => setActiveView('library')}
                onOpenAdmin={() => setActiveView('admin')}
                onOpenLegalPage={openPageBySlug}
              />
            ) : activeView === 'admin' && user && isAdmin ? (
              <AdminDashboard
                currentUser={user}
                initialEditingPage={adminInitialEditPage}
                onClearInitialEditingPage={() => setAdminInitialEditPage(null)}
                onBackToLibrary={() => setActiveView('library')}
                onPreviewPage={(page) => {
                  setActivePageSlug(page.slug);
                  setActiveView('page');
                }}
              />
            ) : activeView === 'page' ? (
              <SitePageView
                page={activeSitePage}
                onBack={() => setActiveView('library')}
                isAdmin={isAdmin}
                onEditPage={(page) => {
                  setAdminInitialEditPage(page);
                  setActiveView('admin');
                }}
              />
            ) : selectedVideo ? (
              <VideoInspector
                video={selectedVideo}
                collections={collections}
                initialSeekSeconds={pendingSeekSeconds}
                uploadedPreviewUrl={
                  uploadedObjectUrls[selectedVideo.id] ||
                  (selectedVideo.localMediaId ? uploadedObjectUrls[selectedVideo.localMediaId] : undefined)
                }
                onBack={() => {
                  setSelectedVideoId(null);
                  setPendingSeekSeconds(null);
                }}
                onToggleFavorite={(v) => void handleToggleFavorite(v)}
                onChangeCollection={(vid, colId) => void handleChangeCollection(vid, colId)}
                onUpdateTags={(vid, tags) => void handleUpdateTags(vid, tags)}
                onUpdateNotes={(vid, notes, saveReason) =>
                  void handleUpdateNotes(vid, notes, saveReason)
                }
                onUpdateLinks={(vid, links) => void handleUpdateLinks(vid, links)}
                onDeleteVideo={(vid) => void handleDeleteVideo(vid)}
                onSelectTagFilter={(tag) => {
                  setSelectedTag(tag);
                  setSelectedVideoId(null);
                }}
              />
            ) : (
              <div className="space-y-6">
                {/* Universal Share Intake Bar */}
                <section className="border border-slate-200 dark:border-slate-800 rounded-xl bg-white dark:bg-slate-900 p-4 sm:p-5 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <h1 className="text-lg font-semibold text-slate-900 dark:text-slate-100">
                        {activeCollectionName
                          ? activeCollectionName
                          : sidebarFilter.type === 'favorites'
                            ? 'Favorite Items'
                            : selectedItemType === 'screenshot'
                              ? 'Saved Screenshots'
                              : selectedItemType === 'link'
                                ? 'Web & Product Links'
                                : selectedItemType === 'video'
                                  ? 'Saved Videos'
                                  : 'Universal Share Inbox'}
                      </h1>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        Paste any video or product/web link, add why you saved it, or paste a screenshot (<kbd className="px-1 py-0.5 text-[10px] border border-slate-300 dark:border-slate-700 rounded">Ctrl+V</kbd>). Local uploads stay on your device.
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      <button
                        type="button"
                        onClick={() => {
                          setAnalyzeError(null);
                          setIsIncomingShare(false);
                          setSubmitInitialMode('screenshot');
                          setSubmitInitialFile(null);
                          setIsSubmitOpen(true);
                        }}
                        className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 px-2.5 py-1 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap"
                      >
                        <ImageIcon className="w-3.5 h-3.5 text-blue-600" />
                        Add Screenshot
                      </button>
                      <button
                        type="button"
                        onClick={() => setIsShareSetupOpen(true)}
                        className="text-xs font-medium text-blue-600 dark:text-blue-400 hover:underline whitespace-nowrap"
                      >
                        How mobile Share works
                      </button>
                    </div>
                  </div>

                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (!quickLinkInput.trim() || isAnalyzing) return;
                      void handleAnalyzeUrl({
                        rawInput: quickLinkInput.trim(),
                        saveReason: quickSaveReason || undefined,
                        notes: quickNoteInput.trim() || undefined,
                      });
                    }}
                    className="space-y-2.5"
                  >
                    <div className="flex flex-col sm:flex-row gap-2.5">
                      <input
                        type="text"
                        value={quickLinkInput}
                        onChange={(e) => setQuickLinkInput(e.target.value)}
                        placeholder="Paste video URL (YouTube, TikTok, IG, FB) or any website / product link..."
                        disabled={isAnalyzing}
                        className="flex-1 px-3.5 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/30 focus:border-blue-600"
                      />
                      <select
                        aria-label="Why I saved this"
                        value={quickSaveReason}
                        onChange={(e) => setQuickSaveReason(e.target.value)}
                        disabled={isAnalyzing}
                        className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-200"
                      >
                        <option value="">Why I saved this (optional)</option>
                        {SAVE_REASON_PRESETS.map((p) => (
                          <option key={p} value={p}>
                            {p}
                          </option>
                        ))}
                      </select>
                      <button
                        type="submit"
                        disabled={isAnalyzing || !quickLinkInput.trim()}
                        className="inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap shrink-0"
                      >
                        {isAnalyzing ? (
                          <>
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            Analyzing...
                          </>
                        ) : (
                          'Save & Index'
                        )}
                      </button>
                    </div>
                    {(quickLinkInput.trim() || quickSaveReason || quickNoteInput) && (
                      <input
                        type="text"
                        maxLength={400}
                        value={quickNoteInput}
                        onChange={(e) => setQuickNoteInput(e.target.value)}
                        placeholder="Quick note: why are you saving this? (e.g. 'check price later' or 'tool mentioned for zotomic')"
                        disabled={isAnalyzing}
                        className="w-full px-3.5 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-slate-800 dark:text-slate-200 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/30"
                      />
                    )}
                  </form>

                  {analyzeError && !isSubmitOpen && (
                    <p className="text-xs text-red-600 dark:text-red-400">{analyzeError}</p>
                  )}
                </section>

                {/* Platform Segmented Controls & Active Filter Bar */}
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-1 p-1 bg-slate-200/70 dark:bg-slate-800/80 rounded-lg overflow-x-auto max-w-full">
                    {platformTabs.map((tab) => (
                      <button
                        key={tab.id}
                        type="button"
                        onClick={() => setSelectedPlatform(tab.id)}
                        className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                          selectedPlatform === tab.id
                            ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                            : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
                        }`}
                      >
                        {tab.label}
                      </button>
                    ))}
                  </div>

                  <div className="flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
                    <span className="tabular-nums">
                      {filteredVideos.length} {filteredVideos.length === 1 ? 'item' : 'items'}
                      {selectedItemType !== 'all' ? ` · ${selectedItemType}` : ''}
                      {selectedPlatform !== 'all' ? ` · ${PLATFORM_LABELS[selectedPlatform]}` : ''}
                      {selectedTag ? ` · #${selectedTag}` : ''}
                    </span>
                    {(selectedItemType !== 'all' ||
                      selectedPlatform !== 'all' ||
                      selectedTag ||
                      searchQuery.trim()) && (
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedItemType('all');
                          setSelectedPlatform('all');
                          setSelectedTag(null);
                          setSearchQuery('');
                        }}
                        className="text-blue-600 dark:text-blue-400 hover:underline font-medium whitespace-nowrap"
                      >
                        Reset filters
                      </button>
                    )}
                  </div>
                </div>

                {/* Library Feed */}
                <VideoLibraryList
                  videos={filteredVideos}
                  collections={collections}
                  localObjectUrls={uploadedObjectUrls}
                  searchQuery={searchQuery}
                  selectedItemType={selectedItemType}
                  selectedPlatform={selectedPlatform}
                  selectedTag={selectedTag}
                  selectedVideoId={selectedVideoId}
                  onSelectVideo={(id, jumpSec) => {
                    setSelectedVideoId(id);
                    setPendingSeekSeconds(typeof jumpSec === 'number' ? jumpSec : null);
                  }}
                  onSelectTag={(tag) => setSelectedTag(tag)}
                  onToggleFavorite={(v) => void handleToggleFavorite(v)}
                  onDeleteVideo={(vid) => void handleDeleteVideo(vid)}
                  onOpenSubmit={() => {
                    setAnalyzeError(null);
                    setIsIncomingShare(false);
                    setSubmitInitialMode('link');
                    setIsSubmitOpen(true);
                  }}
                />
              </div>
            )}
          </div>

          {/* Clean Legal Footer */}
          <footer className="pt-6 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-500 dark:text-slate-400">
            <span>
              {siteSettings.siteName}
              {siteSettings.tagline ? ` · ${siteSettings.tagline}` : ''}
            </span>
            <div className="flex flex-wrap items-center gap-4">
              {displayPages.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => openPageBySlug(p.slug)}
                  className="hover:text-slate-900 dark:hover:text-slate-100 hover:underline"
                >
                  {p.title}
                </button>
              ))}
            </div>
          </footer>
        </main>
      </div>

      <VideoSubmitPanel
        isOpen={isSubmitOpen}
        onClose={() => {
          if (!isAnalyzing) {
            setIsSubmitOpen(false);
            setIsIncomingShare(false);
          }
        }}
        collections={collections}
        initialUrl={submitInitialUrl}
        initialTitle={submitInitialTitle}
        initialMode={submitInitialMode}
        initialFile={submitInitialFile}
        isIncomingShare={isIncomingShare}
        isSubmitting={isAnalyzing}
        errorMessage={analyzeError}
        usageQuota={usageQuota}
        onSubmitUrl={handleAnalyzeUrl}
        onSubmitFile={handleAnalyzeFile}
      />

      <ShareSetupModal
        isOpen={isShareSetupOpen}
        onClose={() => setIsShareSetupOpen(false)}
        onTestShareUrl={(url, title) => {
          setAnalyzeError(null);
          setSubmitInitialMode('link');
          setSubmitInitialUrl(url);
          setSubmitInitialTitle(title);
          setIsIncomingShare(true);
          setIsSubmitOpen(true);
        }}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        currentUser={user}
        onOpenLegalPage={openPageBySlug}
        onUserVerified={() => {
          if (auth.currentUser) {
            void ensureUserProfile(auth.currentUser);
            void checkUserIsAdmin(auth.currentUser).then(setIsAdmin);
          }
        }}
      />

      <OfflineIndicator />
    </div>
  );
}
