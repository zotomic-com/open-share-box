import React, { useEffect, useState } from 'react';
import { HardDrive, Image as ImageIcon, Link2, Loader2, Upload, X } from 'lucide-react';
import type { VideoCollection } from '../types/video';
import type { ClientUsageQuota } from '../lib/apiClient';
import { SAVE_REASON_PRESETS } from '../lib/videoUtils';

interface VideoSubmitPanelProps {
  isOpen: boolean;
  onClose: () => void;
  collections: VideoCollection[];
  initialUrl?: string;
  initialTitle?: string;
  initialMode?: 'link' | 'screenshot' | 'file';
  initialFile?: File | null;
  isIncomingShare?: boolean;
  isSubmitting: boolean;
  errorMessage: string | null;
  usageQuota?: ClientUsageQuota | null;
  onSubmitUrl: (params: {
    rawInput: string;
    title?: string;
    customFocus?: string;
    saveReason?: string;
    notes?: string;
    collectionId?: string;
    modeHint?: 'auto' | 'video' | 'link';
  }) => Promise<void>;
  onSubmitFile: (params: {
    file: File;
    title?: string;
    customFocus?: string;
    saveReason?: string;
    notes?: string;
    collectionId?: string;
  }) => Promise<void>;
}

export const VideoSubmitPanel: React.FC<VideoSubmitPanelProps> = ({
  isOpen,
  onClose,
  collections,
  initialUrl = '',
  initialTitle = '',
  initialMode = 'link',
  initialFile = null,
  isIncomingShare = false,
  isSubmitting,
  errorMessage,
  usageQuota = null,
  onSubmitUrl,
  onSubmitFile,
}) => {
  const [mode, setMode] = useState<'link' | 'screenshot' | 'file'>(initialMode);
  const [rawInput, setRawInput] = useState(initialUrl);
  const [urlTypeHint, setUrlTypeHint] = useState<'auto' | 'video' | 'link'>('auto');
  const [customTitle, setCustomTitle] = useState(initialTitle);
  const [saveReason, setSaveReason] = useState('');
  const [userNote, setUserNote] = useState('');
  const [customFocus, setCustomFocus] = useState('');
  const [collectionId, setCollectionId] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(initialFile);
  const [imagePreviewUrl, setImagePreviewUrl] = useState<string>('');
  const [localError, setLocalError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setMode(initialMode);
      if (initialUrl) setRawInput(initialUrl);
      if (initialTitle) setCustomTitle(initialTitle);
      if (initialFile) {
        setSelectedFile(initialFile);
        if (initialFile.type.startsWith('image/')) {
          setMode('screenshot');
        }
      }
      setLocalError(null);
    } else {
      setSaveReason('');
      setUserNote('');
      setCustomFocus('');
      setSelectedFile(null);
    }
  }, [isOpen, initialUrl, initialTitle, initialMode, initialFile]);

  useEffect(() => {
    if (selectedFile && selectedFile.type.startsWith('image/')) {
      const objUrl = URL.createObjectURL(selectedFile);
      setImagePreviewUrl(objUrl);
      return () => URL.revokeObjectURL(objUrl);
    }
    setImagePreviewUrl('');
    return undefined;
  }, [selectedFile]);

  // Support Ctrl+V / Cmd+V screenshot paste while modal is open
  useEffect(() => {
    if (!isOpen) return;
    const handlePaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;
      for (const item of items) {
        if (item.type.startsWith('image/')) {
          const blob = item.getAsFile();
          if (blob) {
            e.preventDefault();
            const ext = item.type.split('/')[1] || 'png';
            const pastedFile = new File([blob], `screenshot_${Date.now()}.${ext}`, {
              type: item.type,
            });
            setSelectedFile(pastedFile);
            setMode('screenshot');
            setLocalError(null);
            break;
          }
        }
      }
    };
    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, [isOpen]);

  if (!isOpen) return null;

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError(null);

    if (mode === 'link') {
      if (!rawInput.trim()) {
        setLocalError(
          'Paste a video link (YouTube, TikTok, Instagram, Facebook) or a web/product/service URL.'
        );
        return;
      }
      await onSubmitUrl({
        rawInput: rawInput.trim(),
        title: customTitle.trim() || undefined,
        customFocus: customFocus.trim() || undefined,
        saveReason: saveReason.trim() || undefined,
        notes: userNote.trim() || undefined,
        collectionId: collectionId || undefined,
        modeHint: urlTypeHint,
      });
    } else if (mode === 'screenshot') {
      if (!selectedFile || !selectedFile.type.startsWith('image/')) {
        setLocalError('Select or paste (Ctrl+V) a screenshot image (PNG, JPG, WebP).');
        return;
      }
      if (selectedFile.size > 15 * 1024 * 1024) {
        setLocalError('Screenshot exceeds 15 MB limit.');
        return;
      }
      await onSubmitFile({
        file: selectedFile,
        title: customTitle.trim() || undefined,
        customFocus: customFocus.trim() || undefined,
        saveReason: saveReason.trim() || undefined,
        notes: userNote.trim() || undefined,
        collectionId: collectionId || undefined,
      });
    } else {
      if (!selectedFile) {
        setLocalError('Choose a video or audio clip (max 25 MB).');
        return;
      }
      if (selectedFile.size > 25 * 1024 * 1024) {
        setLocalError('Clip size exceeds 25 MB limit. Please select a shorter clip.');
        return;
      }
      await onSubmitFile({
        file: selectedFile,
        title: customTitle.trim() || undefined,
        customFocus: customFocus.trim() || undefined,
        saveReason: saveReason.trim() || undefined,
        notes: userNote.trim() || undefined,
        collectionId: collectionId || undefined,
      });
    }
  };

  const displayError = localError || errorMessage;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="w-full max-w-xl rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden max-h-[92vh] flex flex-col">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 shrink-0">
          <div>
            <h2 className="text-base font-semibold text-slate-900 dark:text-slate-100">
              {isIncomingShare ? 'Save Shared Item & Why You Saved It' : 'Add to Universal Share Inbox'}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Videos, screenshots, or web/product links — indexed with links, tags, and your reason.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            disabled={isSubmitting}
            className="p-1.5 text-slate-500 hover:text-slate-900 dark:hover:text-slate-100 rounded-lg disabled:opacity-50"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={(e) => void handleFormSubmit(e)} className="p-6 space-y-4 overflow-y-auto">
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-lg">
            <button
              type="button"
              onClick={() => setMode('link')}
              className={`flex-1 inline-flex items-center justify-center gap-1.5 py-2 px-2.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                mode === 'link'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
              }`}
            >
              <Link2 className="w-3.5 h-3.5" />
              Video or Web Link
            </button>
            <button
              type="button"
              onClick={() => setMode('screenshot')}
              className={`flex-1 inline-flex items-center justify-center gap-1.5 py-2 px-2.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                mode === 'screenshot'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
              }`}
            >
              <ImageIcon className="w-3.5 h-3.5" />
              Screenshot
            </button>
            <button
              type="button"
              onClick={() => setMode('file')}
              className={`flex-1 inline-flex items-center justify-center gap-1.5 py-2 px-2.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                mode === 'file'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
              }`}
            >
              <Upload className="w-3.5 h-3.5" />
              Local Video
            </button>
          </div>

          {mode === 'link' ? (
            <div className="space-y-2">
              <div className="flex items-center justify-between gap-2">
                <label
                  htmlFor="video-url-input"
                  className="block text-xs font-medium text-slate-700 dark:text-slate-300"
                >
                  Shared URL (Video, Product, Service, or Article)
                </label>
                <select
                  aria-label="Link type hint"
                  value={urlTypeHint}
                  onChange={(e) => setUrlTypeHint(e.target.value as 'auto' | 'video' | 'link')}
                  disabled={isSubmitting}
                  className="px-2 py-1 text-[11px] rounded-md border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300"
                >
                  <option value="auto">Auto-detect type</option>
                  <option value="video">Video link</option>
                  <option value="link">Web / Product link</option>
                </select>
              </div>
              <textarea
                id="video-url-input"
                rows={2}
                value={rawInput}
                onChange={(e) => setRawInput(e.target.value)}
                placeholder="Paste a YouTube, TikTok, Instagram, Facebook video link, or any website/product URL..."
                disabled={isSubmitting}
                className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/30 focus:border-blue-600"
              />
            </div>
          ) : mode === 'screenshot' ? (
            <div className="space-y-2.5">
              <label
                htmlFor="screenshot-file-input"
                className="block text-xs font-medium text-slate-700 dark:text-slate-300"
              >
                Upload or Paste Screenshot (<kbd className="px-1 py-0.5 text-[10px] border border-slate-300 dark:border-slate-700 rounded">Ctrl+V</kbd>)
              </label>
              <input
                id="screenshot-file-input"
                type="file"
                accept="image/*"
                disabled={isSubmitting}
                onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                className="w-full text-xs text-slate-600 dark:text-slate-300 file:mr-3 file:py-2 file:px-3.5 file:rounded-lg file:border file:border-slate-200 dark:file:border-slate-700 file:text-xs file:font-medium file:bg-slate-50 dark:file:bg-slate-800 file:text-slate-800 dark:file:text-slate-100 hover:file:bg-slate-100"
              />
              {imagePreviewUrl && (
                <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-2">
                  <img
                    src={imagePreviewUrl}
                    alt="Screenshot preview"
                    className="max-h-44 mx-auto rounded object-contain"
                  />
                </div>
              )}
              <p className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400">
                <HardDrive className="w-3.5 h-3.5 shrink-0" />
                Image stays on this device&apos;s local storage; only extracted text, links, and tags sync to cloud.
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              <label
                htmlFor="video-file-input"
                className="block text-xs font-medium text-slate-700 dark:text-slate-300"
              >
                Video or Audio File (MP4, WebM, MOV, MP3 — up to 25 MB)
              </label>
              <input
                id="video-file-input"
                type="file"
                accept="video/mp4,video/webm,video/quicktime,audio/*"
                disabled={isSubmitting}
                onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                className="w-full text-xs text-slate-600 dark:text-slate-300 file:mr-3 file:py-2 file:px-3.5 file:rounded-lg file:border file:border-slate-200 dark:file:border-slate-700 file:text-xs file:font-medium file:bg-slate-50 dark:file:bg-slate-800 file:text-slate-800 dark:file:text-slate-100 hover:file:bg-slate-100"
              />
              <p className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400">
                <HardDrive className="w-3.5 h-3.5 shrink-0" />
                Video file is saved locally on your device — never uploaded into the database (only reference link &amp; AI index are stored).
              </p>
            </div>
          )}

          {/* Quick "Why I saved this" Tag + Note */}
          <div className="p-3.5 rounded-xl border border-blue-200/80 dark:border-blue-900/50 bg-blue-50/40 dark:bg-blue-950/20 space-y-3">
            <div className="space-y-1.5">
              <div className="flex items-center justify-between gap-2">
                <label className="block text-xs font-semibold text-slate-800 dark:text-slate-200">
                  Why I saved this (Quick Tag)
                </label>
                {saveReason && (
                  <button
                    type="button"
                    onClick={() => setSaveReason('')}
                    className="text-[11px] text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
                  >
                    Clear
                  </button>
                )}
              </div>
              <div className="flex flex-wrap gap-1.5">
                {SAVE_REASON_PRESETS.map((preset) => {
                  const active = saveReason === preset;
                  return (
                    <button
                      key={preset}
                      type="button"
                      disabled={isSubmitting}
                      onClick={() => setSaveReason(active ? '' : preset)}
                      className={`px-2.5 py-1 text-xs rounded-md border transition-colors ${
                        active
                          ? 'border-blue-600 bg-blue-600 text-white font-medium'
                          : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:border-blue-400'
                      }`}
                    >
                      {preset}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="space-y-1.5">
              <label
                htmlFor="why-saved-note"
                className="block text-xs font-medium text-slate-700 dark:text-slate-300"
              >
                Why I&apos;m sharing / saving this note (optional)
              </label>
              <input
                id="why-saved-note"
                type="text"
                maxLength={500}
                value={userNote}
                onChange={(e) => setUserNote(e.target.value)}
                placeholder="e.g. Compare this SaaS pricing with zotomic, or check the mic link at 02:15..."
                disabled={isSubmitting}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/30"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label
                htmlFor="video-title-input"
                className="block text-xs font-medium text-slate-700 dark:text-slate-300"
              >
                Title Override (optional)
              </label>
              <input
                id="video-title-input"
                type="text"
                value={customTitle}
                onChange={(e) => setCustomTitle(e.target.value)}
                placeholder="Auto-detected from content"
                disabled={isSubmitting}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/30 focus:border-blue-600"
              />
            </div>

            <div className="space-y-1.5">
              <label
                htmlFor="video-collection-select"
                className="block text-xs font-medium text-slate-700 dark:text-slate-300"
              >
                Save to Collection
              </label>
              <select
                id="video-collection-select"
                value={collectionId}
                onChange={(e) => setCollectionId(e.target.value)}
                disabled={isSubmitting}
                className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600/30 focus:border-blue-600"
              >
                <option value="">All Items (Unassigned)</option>
                {collections.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="space-y-1.5">
            <label
              htmlFor="video-focus-input"
              className="block text-xs font-medium text-slate-700 dark:text-slate-300"
            >
              AI Extraction Focus (optional)
            </label>
            <input
              id="video-focus-input"
              type="text"
              value={customFocus}
              onChange={(e) => setCustomFocus(e.target.value)}
              placeholder="e.g. Extract product links, pricing, tool names, or step-by-step workflow"
              disabled={isSubmitting}
              className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/30 focus:border-blue-600"
            />
          </div>

          {displayError && (
            <div className="px-3.5 py-2.5 rounded-lg border border-red-200 dark:border-red-900/60 bg-red-50 dark:bg-red-950/30 text-xs text-red-700 dark:text-red-300">
              {displayError}
            </div>
          )}

          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-200 dark:border-slate-800">
            <div className="text-[11px] text-slate-500 dark:text-slate-400">
              {usageQuota ? (
                usageQuota.authenticated ? (
                  <span>
                    Daily allowance:{' '}
                    <strong className="text-slate-700 dark:text-slate-200">
                      {usageQuota.analyze.remainingToday}/{usageQuota.analyze.limitToday}
                    </strong>{' '}
                    left today ({usageQuota.analyze.rpmLimit}/min max)
                  </span>
                ) : (
                  <span>
                    Guest limit:{' '}
                    <strong className="text-slate-700 dark:text-slate-200">
                      {usageQuota.analyze.remainingToday}/{usageQuota.analyze.limitToday}
                    </strong>{' '}
                    today · Sign in for higher daily allowance
                  </span>
                )
              ) : (
                <span>Protected by free-tier rate limits</span>
              )}
            </div>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onClose}
                disabled={isSubmitting}
                className="px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
              >
                Cancel
              </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  Analyzing &amp; Indexing...
                </>
              ) : (
                'Analyze & Save'
              )}
            </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
