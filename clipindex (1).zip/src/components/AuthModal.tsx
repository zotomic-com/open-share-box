import React, { useState } from 'react';
import {
  createUserWithEmailAndPassword,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  updateProfile,
} from 'firebase/auth';
import type { User } from 'firebase/auth';
import { CheckCircle2, KeyRound, Loader2, Mail, X } from 'lucide-react';
import { auth, googleProvider } from '../lib/firebase';

type AuthMode = 'login' | 'signup' | 'forgot';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User | null;
  onOpenLegalPage: (slug: string) => void;
  onUserVerified?: () => void;
}

function mapAuthError(err: unknown): string {
  const msg = err instanceof Error ? err.message : String(err);
  if (msg.includes('auth/operation-not-allowed')) {
    return 'Email/Password sign-in is not enabled in Firebase Console yet. Enable it under Authentication > Sign-in method, or use Continue with Google.';
  }
  if (msg.includes('auth/invalid-credential') || msg.includes('auth/wrong-password')) {
    return 'Invalid email or password. Check your credentials or reset your password.';
  }
  if (msg.includes('auth/user-not-found')) {
    return 'No account found with that email address.';
  }
  if (msg.includes('auth/email-already-in-use')) {
    return 'An account with this email already exists. Try signing in instead.';
  }
  if (msg.includes('auth/weak-password')) {
    return 'Password should be at least 6 characters long.';
  }
  if (msg.includes('auth/invalid-email')) {
    return 'Please enter a valid email address.';
  }
  if (msg.includes('auth/popup-closed-by-user')) {
    return 'Sign-in popup was closed before completing.';
  }
  return msg || 'Authentication failed. Please try again.';
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onOpenLegalPage,
  onUserVerified,
}) => {
  const [mode, setMode] = useState<AuthMode>('login');
  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [noticeMessage, setNoticeMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const needsVerification = Boolean(currentUser && !currentUser.emailVerified);

  const handleGoogleSignIn = async () => {
    setErrorMessage(null);
    setNoticeMessage(null);
    setIsSubmitting(true);
    try {
      await signInWithPopup(auth, googleProvider);
      onClose();
    } catch (err) {
      setErrorMessage(mapAuthError(err));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setNoticeMessage(null);

    const cleanEmail = email.trim();
    if (!cleanEmail) {
      setErrorMessage('Please enter your email address.');
      return;
    }

    setIsSubmitting(true);
    try {
      if (mode === 'forgot') {
        await sendPasswordResetEmail(auth, cleanEmail);
        setNoticeMessage(`Password reset link sent to ${cleanEmail}. Check your inbox.`);
        return;
      }

      if (mode === 'signup') {
        if (!displayName.trim()) {
          setErrorMessage('Please enter your full name.');
          return;
        }
        if (password.length < 6) {
          setErrorMessage('Password must be at least 6 characters.');
          return;
        }
        if (password !== confirmPassword) {
          setErrorMessage('Passwords do not match.');
          return;
        }

        const cred = await createUserWithEmailAndPassword(auth, cleanEmail, password);
        await updateProfile(cred.user, { displayName: displayName.trim().slice(0, 120) });
        await sendEmailVerification(cred.user);
        setNoticeMessage(
          `Account created. A verification link was sent to ${cleanEmail}. Verify your email to activate cloud sync.`
        );
        return;
      }

      const cred = await signInWithEmailAndPassword(auth, cleanEmail, password);
      if (cred.user.emailVerified) {
        onClose();
      } else {
        setNoticeMessage('Please verify your email address to enable cloud sync.');
      }
    } catch (err) {
      setErrorMessage(mapAuthError(err));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResendVerification = async () => {
    if (!currentUser) return;
    setErrorMessage(null);
    setNoticeMessage(null);
    setIsSubmitting(true);
    try {
      await sendEmailVerification(currentUser);
      setNoticeMessage(`Verification email resent to ${currentUser.email}.`);
    } catch (err) {
      setErrorMessage(mapAuthError(err));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRefreshVerification = async () => {
    if (!currentUser) return;
    setErrorMessage(null);
    setIsSubmitting(true);
    try {
      await currentUser.reload();
      await currentUser.getIdToken(true);
      if (auth.currentUser?.emailVerified) {
        onUserVerified?.();
        onClose();
      } else {
        setErrorMessage('Email is still unverified. Click the link in your inbox first.');
      }
    } catch (err) {
      setErrorMessage(mapAuthError(err));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="w-full max-w-md rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800">
          <h2 className="text-base font-semibold text-slate-900 dark:text-slate-100">
            {needsVerification
              ? 'Verify Your Email'
              : mode === 'login'
                ? 'Sign In to ClipIndex'
                : mode === 'signup'
                  ? 'Create Your Account'
                  : 'Reset Password'}
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-500 hover:text-slate-900 dark:hover:text-slate-100 rounded-lg"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          {needsVerification ? (
            <div className="space-y-4">
              <div className="p-4 rounded-lg border border-amber-200 dark:border-amber-900/60 bg-amber-50 dark:bg-amber-950/30 space-y-1.5">
                <div className="flex items-center gap-2 text-sm font-semibold text-amber-900 dark:text-amber-200">
                  <Mail className="w-4 h-4" />
                  Email verification required
                </div>
                <p className="text-xs text-amber-800 dark:text-amber-300 leading-relaxed">
                  We sent a verification link to <strong>{currentUser?.email}</strong>. Click the
                  link in your email, then click Refresh Status below to unlock your cloud library.
                </p>
              </div>

              {errorMessage && (
                <p className="text-xs text-red-600 dark:text-red-400">{errorMessage}</p>
              )}
              {noticeMessage && (
                <p className="text-xs text-emerald-700 dark:text-emerald-400">{noticeMessage}</p>
              )}

              <div className="flex flex-col sm:flex-row gap-2.5">
                <button
                  type="button"
                  disabled={isSubmitting}
                  onClick={() => void handleRefreshVerification()}
                  className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Refresh Status
                </button>
                <button
                  type="button"
                  disabled={isSubmitting}
                  onClick={() => void handleResendVerification()}
                  className="px-4 py-2 text-xs font-medium border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg transition-colors"
                >
                  Resend Email
                </button>
              </div>
            </div>
          ) : (
            <>
              {/* Mode switcher */}
              {mode !== 'forgot' && (
                <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-lg">
                  <button
                    type="button"
                    onClick={() => {
                      setMode('login');
                      setErrorMessage(null);
                      setNoticeMessage(null);
                    }}
                    className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-colors ${
                      mode === 'login'
                        ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
                    }`}
                  >
                    Sign In
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setMode('signup');
                      setErrorMessage(null);
                      setNoticeMessage(null);
                    }}
                    className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-colors ${
                      mode === 'signup'
                        ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
                    }`}
                  >
                    Create Account
                  </button>
                </div>
              )}

              <button
                type="button"
                disabled={isSubmitting}
                onClick={() => void handleGoogleSignIn()}
                className="w-full inline-flex items-center justify-center gap-2.5 px-4 py-2.5 text-xs font-medium text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg transition-colors"
              >
                <span className="font-semibold text-blue-600 dark:text-blue-400">G</span>
                Continue with Google
              </button>

              <div className="relative flex items-center">
                <div className="flex-1 border-t border-slate-200 dark:border-slate-800" />
                <span className="px-3 text-[11px] text-slate-400">or with email</span>
                <div className="flex-1 border-t border-slate-200 dark:border-slate-800" />
              </div>

              <form onSubmit={(e) => void handleEmailSubmit(e)} className="space-y-3.5">
                {mode === 'signup' && (
                  <div className="space-y-1">
                    <label
                      htmlFor="auth-name"
                      className="block text-xs font-medium text-slate-700 dark:text-slate-300"
                    >
                      Full Name
                    </label>
                    <input
                      id="auth-name"
                      type="text"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      placeholder="Alex Rivera"
                      required
                      className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600/30 focus:border-blue-600"
                    />
                  </div>
                )}

                <div className="space-y-1">
                  <label
                    htmlFor="auth-email"
                    className="block text-xs font-medium text-slate-700 dark:text-slate-300"
                  >
                    Email Address
                  </label>
                  <input
                    id="auth-email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    required
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600/30 focus:border-blue-600"
                  />
                </div>

                {mode !== 'forgot' && (
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <label
                        htmlFor="auth-password"
                        className="block text-xs font-medium text-slate-700 dark:text-slate-300"
                      >
                        Password
                      </label>
                      {mode === 'login' && (
                        <button
                          type="button"
                          onClick={() => {
                            setMode('forgot');
                            setErrorMessage(null);
                            setNoticeMessage(null);
                          }}
                          className="text-xs text-blue-600 dark:text-blue-400 hover:underline"
                        >
                          Forgot password?
                        </button>
                      )}
                    </div>
                    <input
                      id="auth-password"
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      required
                      minLength={6}
                      className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600/30 focus:border-blue-600"
                    />
                  </div>
                )}

                {mode === 'signup' && (
                  <div className="space-y-1">
                    <label
                      htmlFor="auth-confirm-password"
                      className="block text-xs font-medium text-slate-700 dark:text-slate-300"
                    >
                      Confirm Password
                    </label>
                    <input
                      id="auth-confirm-password"
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="••••••••"
                      required
                      minLength={6}
                      className="w-full px-3 py-2 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600/30 focus:border-blue-600"
                    />
                  </div>
                )}

                {errorMessage && (
                  <div className="px-3 py-2 rounded-lg border border-red-200 dark:border-red-900/60 bg-red-50 dark:bg-red-950/30 text-xs text-red-700 dark:text-red-300">
                    {errorMessage}
                  </div>
                )}

                {noticeMessage && (
                  <div className="px-3 py-2 rounded-lg border border-emerald-200 dark:border-emerald-900/60 bg-emerald-50 dark:bg-emerald-950/30 text-xs text-emerald-700 dark:text-emerald-300">
                    {noticeMessage}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-60 rounded-lg transition-colors"
                >
                  {isSubmitting ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : mode === 'forgot' ? (
                    <KeyRound className="w-3.5 h-3.5" />
                  ) : null}
                  {mode === 'login'
                    ? 'Sign In'
                    : mode === 'signup'
                      ? 'Create Account'
                      : 'Send Reset Link'}
                </button>

                {mode === 'forgot' && (
                  <button
                    type="button"
                    onClick={() => {
                      setMode('login');
                      setErrorMessage(null);
                      setNoticeMessage(null);
                    }}
                    className="w-full py-1.5 text-xs text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100"
                  >
                    Back to Sign In
                  </button>
                )}
              </form>

              <p className="text-[11px] text-slate-500 dark:text-slate-400 text-center leading-relaxed">
                By continuing, you agree to our{' '}
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenLegalPage('terms-of-service');
                  }}
                  className="underline hover:text-slate-900 dark:hover:text-slate-100"
                >
                  Terms of Service
                </button>{' '}
                and{' '}
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenLegalPage('privacy-policy');
                  }}
                  className="underline hover:text-slate-900 dark:hover:text-slate-100"
                >
                  Privacy Policy
                </button>
                .
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
