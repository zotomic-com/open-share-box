export type InboxItemType = 'video' | 'screenshot' | 'link';

export type VideoPlatform =
  | 'youtube'
  | 'tiktok'
  | 'instagram'
  | 'facebook'
  | 'vimeo'
  | 'x'
  | 'web'
  | 'screenshot'
  | 'upload'
  | 'other';

export interface VideoSegment {
  timestamp: string;
  seconds: number;
  title: string;
  summary: string;
  keyQuote?: string;
}

export interface TranscriptEntry {
  timestamp: string;
  seconds: number;
  speaker?: string;
  text: string;
}

export interface ExtractedLink {
  url: string;
  label: string;
  kind?: 'product' | 'service' | 'resource' | 'social' | 'other';
  context?: string;
}

export interface AnalyzedVideo {
  id: string;
  ownerId: string;
  itemType?: InboxItemType;
  url: string;
  platform: VideoPlatform;
  title: string;
  creator: string;
  thumbnailUrl: string;
  durationLabel: string;
  category: string;
  collectionId: string;
  isFavorite: boolean;
  saveReason?: string;
  localMediaId?: string;
  summary: string;
  tldrBullets: string[];
  tags: string[];
  segments: VideoSegment[];
  transcript: TranscriptEntry[];
  links?: ExtractedLink[];
  notes: string;
  createdAtMs: number;
  updatedAtMs: number;
}

export interface VideoCollection {
  id: string;
  ownerId: string;
  name: string;
  description: string;
  createdAtMs: number;
  updatedAtMs: number;
}

export interface AnalyzeVideoResponse {
  itemType?: InboxItemType;
  url: string;
  platform: VideoPlatform;
  title: string;
  creator: string;
  thumbnailUrl: string;
  durationLabel: string;
  category: string;
  summary: string;
  tldrBullets: string[];
  tags: string[];
  segments: VideoSegment[];
  transcript: TranscriptEntry[];
  links?: ExtractedLink[];
  metadataSource: string;
}

export interface VideoChatMessage {
  role: 'user' | 'model';
  text: string;
}

export type UserRole = 'user' | 'admin';
export type UserStatus = 'active' | 'suspended' | 'pending';

export interface UserProfileRecord {
  uid: string;
  displayName: string;
  photoURL?: string;
  role: UserRole;
  status: UserStatus;
  bio: string;
  organization: string;
  location: string;
  videoCount: number;
  createdAtMs: number;
  updatedAtMs: number;
}

export interface UserPrivateRecord {
  uid: string;
  email: string;
  phone: string;
  address: string;
  adminNotes: string;
  createdAtMs: number;
  updatedAtMs: number;
}

export interface FullUserRecord {
  profile: UserProfileRecord;
  privateInfo: UserPrivateRecord | null;
}

export type PageBlockType = 'heading' | 'text' | 'image' | 'video';
export type PageType = 'legal' | 'guide' | 'custom';

export interface PageBlock {
  id: string;
  type: PageBlockType;
  heading?: string;
  content?: string;
  mediaUrl?: string;
  caption?: string;
}

export interface SitePage {
  id: string;
  slug: string;
  title: string;
  subtitle: string;
  pageType: PageType;
  isPublished: boolean;
  blocks: PageBlock[];
  updatedBy: string;
  createdAtMs: number;
  updatedAtMs: number;
}

export type AiBrainDepth = 'fast' | 'balanced';

export interface AiBrainSettings {
  depth: AiBrainDepth;
  language: string;
  customInstruction: string;
}

export interface SiteSettings {
  id: 'site';
  siteName: string;
  tagline: string;
  logoUrl: string;
  faviconUrl: string;
  metaTitle: string;
  metaDescription: string;
  ogImageUrl: string;
  canonicalUrl: string;
  googleSiteVerification: string;
  googleHtmlFileName: string;
  googleHtmlFileContent: string;
  aiDefaultDepth: AiBrainDepth;
  aiDefaultLanguage: string;
  aiCustomInstruction: string;
  updatedBy: string;
  createdAtMs: number;
  updatedAtMs: number;
}

