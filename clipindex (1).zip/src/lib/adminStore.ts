import type { User } from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import type {
  AiBrainDepth,
  AnalyzedVideo,
  FullUserRecord,
  PageBlock,
  PageType,
  SitePage,
  SiteSettings,
  UserPrivateRecord,
  UserProfileRecord,
  UserRole,
  UserStatus,
} from '../types/video';
import { db, handleFirestoreError, OperationType } from './firebase';
import { apiUrl } from './apiClient';
import { toMillis } from './libraryStore';
import { DEFAULT_SITE_PAGES, sanitizeHttpUrl } from './pageDefaults';
import { generateSafeId } from './videoUtils';

export const BOOTSTRAPPED_ADMIN_EMAIL = 'zotomic.com@gmail.com';

export const DEFAULT_SITE_SETTINGS: SiteSettings = {
  id: 'site',
  siteName: 'ClipIndex',
  tagline: 'Video Timestamps, Summaries & Searchable Library',
  logoUrl: '',
  faviconUrl: '',
  metaTitle: 'ClipIndex — Video Timestamps, Summaries & Searchable Library',
  metaDescription:
    'Extract timestamped segments, AI summaries, transcripts, and searchable tags from shared YouTube, TikTok, Instagram, and Facebook videos.',
  ogImageUrl: '',
  canonicalUrl: '',
  googleSiteVerification: '',
  googleHtmlFileName: '',
  googleHtmlFileContent: '',
  aiDefaultDepth: 'fast',
  aiDefaultLanguage: 'English',
  aiCustomInstruction: '',
  updatedBy: 'system',
  createdAtMs: 0,
  updatedAtMs: 0,
};

export function extractGoogleVerificationToken(rawInput: string): string {
  const trimmed = (rawInput || '').trim();
  if (!trimmed) return '';
  const metaMatch = trimmed.match(/content\s*=\s*["']([^"']+)["']/i);
  const candidate = metaMatch?.[1]?.trim() || trimmed;
  return candidate.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 128);
}

export function normalizeGoogleHtmlFilename(rawInput: string): string {
  const trimmed = (rawInput || '').trim().replace(/^\/+/, '');
  if (!trimmed) return '';
  return /^google[a-zA-Z0-9]+\.html$/.test(trimmed) ? trimmed.slice(0, 80) : '';
}

export async function checkUserIsAdmin(user: User | null): Promise<boolean> {
  if (!user || !user.emailVerified) return false;
  if (user.email?.toLowerCase() === BOOTSTRAPPED_ADMIN_EMAIL) return true;
  try {
    const snap = await getDoc(doc(db, 'admins', user.uid));
    return snap.exists();
  } catch {
    return false;
  }
}

function mapUserProfileDoc(id: string, d: Record<string, unknown>): UserProfileRecord {
  return {
    uid: String(d.uid || id),
    displayName: String(d.displayName || 'Unnamed User'),
    photoURL: d.photoURL ? String(d.photoURL) : undefined,
    role: d.role === 'admin' ? 'admin' : 'user',
    status: d.status === 'suspended' || d.status === 'pending' ? d.status : 'active',
    bio: String(d.bio || ''),
    organization: String(d.organization || ''),
    location: String(d.location || ''),
    videoCount: typeof d.videoCount === 'number' ? d.videoCount : 0,
    createdAtMs: toMillis(d.createdAt),
    updatedAtMs: toMillis(d.updatedAt),
  };
}

function mapSitePageDoc(id: string, d: Record<string, unknown>): SitePage {
  const rawBlocks = Array.isArray(d.blocks) ? d.blocks : [];
  const blocks: PageBlock[] = rawBlocks.slice(0, 40).map((b, idx) => {
    const obj = (b && typeof b === 'object' ? b : {}) as Record<string, unknown>;
    const rawType = String(obj.type || 'text');
    const type =
      rawType === 'heading' || rawType === 'image' || rawType === 'video' ? rawType : 'text';
    return {
      id: String(obj.id || `blk_${idx}`),
      type,
      ...(obj.heading ? { heading: String(obj.heading) } : {}),
      ...(obj.content ? { content: String(obj.content) } : {}),
      ...(obj.mediaUrl ? { mediaUrl: sanitizeHttpUrl(String(obj.mediaUrl)) } : {}),
      ...(obj.caption ? { caption: String(obj.caption) } : {}),
    };
  });

  const rawPageType = String(d.pageType || 'custom');
  const pageType: PageType =
    rawPageType === 'legal' || rawPageType === 'guide' ? rawPageType : 'custom';

  return {
    id: String(d.id || id),
    slug: String(d.slug || id),
    title: String(d.title || 'Untitled Page'),
    subtitle: String(d.subtitle || ''),
    pageType,
    isPublished: Boolean(d.isPublished),
    blocks,
    updatedBy: String(d.updatedBy || 'system'),
    createdAtMs: toMillis(d.createdAt),
    updatedAtMs: toMillis(d.updatedAt),
  };
}

export function subscribeAllUsersAdmin(
  onData: (users: UserProfileRecord[]) => void
): () => void {
  const path = 'users';
  return onSnapshot(
    collection(db, path),
    (snapshot) => {
      const list = snapshot.docs
        .map((d) => mapUserProfileDoc(d.id, d.data() as Record<string, unknown>))
        .sort((a, b) => b.createdAtMs - a.createdAtMs);
      onData(list);
    },
    (err) => {
      handleFirestoreError(err, OperationType.LIST, path);
    }
  );
}

export async function fetchUserFullDetailsAdmin(uid: string): Promise<{
  record: FullUserRecord | null;
  videos: AnalyzedVideo[];
}> {
  const userPath = `users/${uid}`;
  const privatePath = `users/${uid}/private/info`;
  const videosPath = `users/${uid}/videos`;

  try {
    const [profileSnap, privateSnap, videosSnap] = await Promise.all([
      getDoc(doc(db, userPath)),
      getDoc(doc(db, privatePath)),
      getDocs(collection(db, videosPath)),
    ]);

    if (!profileSnap.exists()) {
      return { record: null, videos: [] };
    }

    const profile = mapUserProfileDoc(
      profileSnap.id,
      profileSnap.data() as Record<string, unknown>
    );

    let privateInfo: UserPrivateRecord | null = null;
    if (privateSnap.exists()) {
      const p = privateSnap.data();
      privateInfo = {
        uid: String(p.uid || uid),
        email: String(p.email || ''),
        phone: String(p.phone || ''),
        address: String(p.address || ''),
        adminNotes: String(p.adminNotes || ''),
        createdAtMs: toMillis(p.createdAt),
        updatedAtMs: toMillis(p.updatedAt),
      };
    }

    const videos: AnalyzedVideo[] = videosSnap.docs
      .map((d) => {
        const data = d.data();
        return {
          id: String(data.id || d.id),
          ownerId: String(data.ownerId || uid),
          url: String(data.url || ''),
          platform: data.platform || 'other',
          title: String(data.title || 'Untitled'),
          creator: String(data.creator || ''),
          thumbnailUrl: String(data.thumbnailUrl || ''),
          durationLabel: String(data.durationLabel || '—'),
          category: String(data.category || 'General'),
          collectionId: String(data.collectionId || ''),
          isFavorite: Boolean(data.isFavorite),
          summary: String(data.summary || ''),
          tldrBullets: Array.isArray(data.tldrBullets) ? data.tldrBullets : [],
          tags: Array.isArray(data.tags) ? data.tags : [],
          segments: Array.isArray(data.segments) ? data.segments : [],
          transcript: Array.isArray(data.transcript) ? data.transcript : [],
          notes: String(data.notes || ''),
          createdAtMs: toMillis(data.createdAt),
          updatedAtMs: toMillis(data.updatedAt),
        };
      })
      .sort((a, b) => b.createdAtMs - a.createdAtMs);

    return {
      record: { profile, privateInfo },
      videos,
    };
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, userPath);
  }
}

export interface AdminUserFormPayload {
  displayName: string;
  email: string;
  phone: string;
  address: string;
  organization: string;
  location: string;
  bio: string;
  role: UserRole;
  status: UserStatus;
  adminNotes: string;
}

export async function adminCreateUser(
  adminUid: string,
  payload: AdminUserFormPayload
): Promise<string> {
  const newUid = generateSafeId('usr');
  const userPath = `users/${newUid}`;
  const privatePath = `users/${newUid}/private/info`;

  try {
    await setDoc(doc(db, userPath), {
      uid: newUid,
      displayName: payload.displayName.trim().slice(0, 120),
      role: payload.role,
      status: payload.status,
      bio: payload.bio.trim().slice(0, 500),
      organization: payload.organization.trim().slice(0, 120),
      location: payload.location.trim().slice(0, 120),
      videoCount: 0,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    await setDoc(doc(db, privatePath), {
      uid: newUid,
      email: payload.email.trim().slice(0, 254),
      phone: payload.phone.trim().slice(0, 40),
      address: payload.address.trim().slice(0, 300),
      adminNotes: payload.adminNotes.trim().slice(0, 2000),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    if (payload.role === 'admin') {
      await setDoc(doc(db, `admins/${newUid}`), {
        uid: newUid,
        grantedBy: adminUid,
        createdAt: serverTimestamp(),
      });
    }
    return newUid;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, userPath);
  }
}

export async function adminUpdateUser(
  adminUid: string,
  targetUid: string,
  payload: AdminUserFormPayload
): Promise<void> {
  const userPath = `users/${targetUid}`;
  const privatePath = `users/${targetUid}/private/info`;

  try {
    await updateDoc(doc(db, userPath), {
      displayName: payload.displayName.trim().slice(0, 120),
      role: payload.role,
      status: payload.status,
      bio: payload.bio.trim().slice(0, 500),
      organization: payload.organization.trim().slice(0, 120),
      location: payload.location.trim().slice(0, 120),
      updatedAt: serverTimestamp(),
    });

    const privateRef = doc(db, privatePath);
    const privateSnap = await getDoc(privateRef);
    if (!privateSnap.exists()) {
      await setDoc(privateRef, {
        uid: targetUid,
        email: payload.email.trim().slice(0, 254),
        phone: payload.phone.trim().slice(0, 40),
        address: payload.address.trim().slice(0, 300),
        adminNotes: payload.adminNotes.trim().slice(0, 2000),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } else {
      await updateDoc(privateRef, {
        email: payload.email.trim().slice(0, 254),
        phone: payload.phone.trim().slice(0, 40),
        address: payload.address.trim().slice(0, 300),
        adminNotes: payload.adminNotes.trim().slice(0, 2000),
        updatedAt: serverTimestamp(),
      });
    }

    const adminGrantRef = doc(db, `admins/${targetUid}`);
    const grantSnap = await getDoc(adminGrantRef);
    if (payload.role === 'admin' && !grantSnap.exists()) {
      await setDoc(adminGrantRef, {
        uid: targetUid,
        grantedBy: adminUid,
        createdAt: serverTimestamp(),
      });
    } else if (payload.role === 'user' && grantSnap.exists()) {
      await deleteDoc(adminGrantRef);
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, userPath);
  }
}

export async function adminDeleteUser(targetUid: string): Promise<void> {
  const userPath = `users/${targetUid}`;
  try {
    const privateRef = doc(db, `users/${targetUid}/private/info`);
    const privateSnap = await getDoc(privateRef);
    if (privateSnap.exists()) {
      await deleteDoc(privateRef);
    }

    const grantRef = doc(db, `admins/${targetUid}`);
    const grantSnap = await getDoc(grantRef);
    if (grantSnap.exists()) {
      await deleteDoc(grantRef);
    }

    await deleteDoc(doc(db, userPath));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, userPath);
  }
}

export function subscribePublishedPages(onData: (pages: SitePage[]) => void): () => void {
  const path = 'pages';
  const q = query(collection(db, path), where('isPublished', '==', true));

  return onSnapshot(
    q,
    (snapshot) => {
      const pages = snapshot.docs
        .map((d) => mapSitePageDoc(d.id, d.data() as Record<string, unknown>))
        .sort((a, b) => a.title.localeCompare(b.title));
      onData(pages);
    },
    (err) => {
      handleFirestoreError(err, OperationType.LIST, path);
    }
  );
}

export function subscribeAllPagesAdmin(onData: (pages: SitePage[]) => void): () => void {
  const path = 'pages';
  return onSnapshot(
    collection(db, path),
    (snapshot) => {
      const pages = snapshot.docs
        .map((d) => mapSitePageDoc(d.id, d.data() as Record<string, unknown>))
        .sort((a, b) => b.updatedAtMs - a.updatedAtMs);
      onData(pages);
    },
    (err) => {
      handleFirestoreError(err, OperationType.LIST, path);
    }
  );
}

export async function saveSitePageAdmin(
  adminUid: string,
  pageInput: {
    id?: string;
    slug: string;
    title: string;
    subtitle: string;
    pageType: PageType;
    isPublished: boolean;
    blocks: PageBlock[];
  }
): Promise<string> {
  const cleanSlug = pageInput.slug
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 100);

  const pageId = (pageInput.id || cleanSlug || generateSafeId('page'))
    .replace(/[^a-zA-Z0-9_-]/g, '-')
    .slice(0, 128);

  const path = `pages/${pageId}`;
  const cleanBlocks = pageInput.blocks.slice(0, 40).map((b, idx) => ({
    id: (b.id || `blk_${idx}`).slice(0, 64),
    type: b.type,
    ...(b.heading ? { heading: b.heading.slice(0, 300) } : {}),
    ...(b.content ? { content: b.content.slice(0, 5000) } : {}),
    ...(b.mediaUrl ? { mediaUrl: sanitizeHttpUrl(b.mediaUrl).slice(0, 2048) } : {}),
    ...(b.caption ? { caption: b.caption.slice(0, 300) } : {}),
  }));

  try {
    const ref = doc(db, path);
    const snap = await getDoc(ref);
    if (!snap.exists()) {
      await setDoc(ref, {
        id: pageId,
        slug: cleanSlug || pageId.toLowerCase(),
        title: pageInput.title.trim().slice(0, 160),
        subtitle: pageInput.subtitle.trim().slice(0, 300),
        pageType: pageInput.pageType,
        isPublished: pageInput.isPublished,
        blocks: cleanBlocks,
        updatedBy: adminUid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } else {
      await updateDoc(ref, {
        slug: cleanSlug || pageId.toLowerCase(),
        title: pageInput.title.trim().slice(0, 160),
        subtitle: pageInput.subtitle.trim().slice(0, 300),
        pageType: pageInput.pageType,
        isPublished: pageInput.isPublished,
        blocks: cleanBlocks,
        updatedBy: adminUid,
        updatedAt: serverTimestamp(),
      });
    }
    return pageId;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export async function deleteSitePageAdmin(pageId: string): Promise<void> {
  const path = `pages/${pageId}`;
  try {
    await deleteDoc(doc(db, path));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

export async function seedDefaultLegalPagesAdmin(adminUid: string): Promise<void> {
  for (const def of DEFAULT_SITE_PAGES) {
    const ref = doc(db, `pages/${def.id}`);
    const snap = await getDoc(ref);
    if (!snap.exists()) {
      await saveSitePageAdmin(adminUid, {
        id: def.id,
        slug: def.slug,
        title: def.title,
        subtitle: def.subtitle,
        pageType: def.pageType,
        isPublished: true,
        blocks: def.blocks,
      });
    }
  }
}

function mapSiteSettingsDoc(d: Record<string, unknown>): SiteSettings {
  const depth: AiBrainDepth = d.aiDefaultDepth === 'balanced' ? 'balanced' : 'fast';
  return {
    id: 'site',
    siteName: String(d.siteName || DEFAULT_SITE_SETTINGS.siteName),
    tagline: String(d.tagline ?? DEFAULT_SITE_SETTINGS.tagline),
    logoUrl: sanitizeHttpUrl(String(d.logoUrl || '')),
    faviconUrl: sanitizeHttpUrl(String(d.faviconUrl || '')),
    metaTitle: String(d.metaTitle ?? DEFAULT_SITE_SETTINGS.metaTitle),
    metaDescription: String(d.metaDescription ?? DEFAULT_SITE_SETTINGS.metaDescription),
    ogImageUrl: sanitizeHttpUrl(String(d.ogImageUrl || '')),
    canonicalUrl: sanitizeHttpUrl(String(d.canonicalUrl || '')),
    googleSiteVerification: extractGoogleVerificationToken(String(d.googleSiteVerification || '')),
    googleHtmlFileName: normalizeGoogleHtmlFilename(String(d.googleHtmlFileName || '')),
    googleHtmlFileContent: String(d.googleHtmlFileContent || ''),
    aiDefaultDepth: depth,
    aiDefaultLanguage: String(d.aiDefaultLanguage || DEFAULT_SITE_SETTINGS.aiDefaultLanguage),
    aiCustomInstruction: String(d.aiCustomInstruction || ''),
    updatedBy: String(d.updatedBy || 'system'),
    createdAtMs: toMillis(d.createdAt),
    updatedAtMs: toMillis(d.updatedAt),
  };
}

export function subscribeSiteSettings(onData: (settings: SiteSettings) => void): () => void {
  const path = 'settings/site';
  return onSnapshot(
    doc(db, path),
    (snapshot) => {
      if (!snapshot.exists()) {
        onData(DEFAULT_SITE_SETTINGS);
        return;
      }
      onData(mapSiteSettingsDoc(snapshot.data() as Record<string, unknown>));
    },
    () => {
      onData(DEFAULT_SITE_SETTINGS);
    }
  );
}

export interface SiteSettingsInput {
  siteName: string;
  tagline: string;
  logoUrl: string;
  faviconUrl: string;
  metaTitle: string;
  metaDescription: string;
  ogImageUrl: string;
  canonicalUrl: string;
  googleSiteVerification: string;
  googleHtmlFileName: string;
  googleHtmlFileContent: string;
  aiDefaultDepth: AiBrainDepth;
  aiDefaultLanguage: string;
  aiCustomInstruction: string;
}

export async function saveSiteSettingsAdmin(
  adminUid: string,
  input: SiteSettingsInput
): Promise<void> {
  const path = 'settings/site';
  const cleanFileName = normalizeGoogleHtmlFilename(input.googleHtmlFileName);
  const cleanFileContent = cleanFileName
    ? (input.googleHtmlFileContent.trim() || `google-site-verification: ${cleanFileName}`).slice(0, 200)
    : '';

  const payload = {
    id: 'site',
    siteName: (input.siteName.trim() || 'ClipIndex').slice(0, 80),
    tagline: input.tagline.trim().slice(0, 160),
    logoUrl: sanitizeHttpUrl(input.logoUrl).slice(0, 1000),
    faviconUrl: sanitizeHttpUrl(input.faviconUrl).slice(0, 1000),
    metaTitle: input.metaTitle.trim().slice(0, 120),
    metaDescription: input.metaDescription.trim().slice(0, 320),
    ogImageUrl: sanitizeHttpUrl(input.ogImageUrl).slice(0, 1000),
    canonicalUrl: sanitizeHttpUrl(input.canonicalUrl).slice(0, 500),
    googleSiteVerification: extractGoogleVerificationToken(input.googleSiteVerification),
    googleHtmlFileName: cleanFileName,
    googleHtmlFileContent: cleanFileContent,
    aiDefaultDepth: input.aiDefaultDepth === 'balanced' ? 'balanced' : 'fast',
    aiDefaultLanguage: (input.aiDefaultLanguage.trim() || 'English').slice(0, 60),
    aiCustomInstruction: input.aiCustomInstruction.trim().slice(0, 1000),
    updatedBy: adminUid,
  };

  try {
    const ref = doc(db, path);
    const snap = await getDoc(ref);
    if (!snap.exists()) {
      await setDoc(ref, {
        ...payload,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } else {
      await updateDoc(ref, {
        ...payload,
        updatedAt: serverTimestamp(),
      });
    }
    fetch(apiUrl('/api/site-settings/invalidate'), { method: 'POST' }).catch(() => {});
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

