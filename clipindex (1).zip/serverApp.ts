import 'dotenv/config';
import express from 'express';
import type { NextFunction, Request, Response } from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';
import type {
  AiBrainSettings,
  AnalyzeVideoResponse,
  ExtractedLink,
  InboxItemType,
  TranscriptEntry,
  VideoPlatform,
  VideoSegment,
} from './src/types/video.ts';
import {
  getCallerUsageSnapshot,
  guardAiRequest,
  isSafePublicHttpUrl,
  verifyCallerIdentity,
} from './serverRateLimit.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const GEMINI_MODEL = 'gemini-4-hydrogen';
export const GEMINI_FALLBACK_MODEL = 'gemini-3.1-flash-lite';

interface FirebaseAppletConfig {
  projectId?: string;
  firestoreDatabaseId?: string;
}

let cachedFirebaseConfig: FirebaseAppletConfig | null = null;
function getFirebaseAppletConfig(): FirebaseAppletConfig {
  if (cachedFirebaseConfig) return cachedFirebaseConfig;

  const envProjectId = (process.env.FIREBASE_PROJECT_ID || '').trim();
  const envDbId = (process.env.FIREBASE_DATABASE_ID || '').trim();

  const candidatePaths = [
    path.resolve(__dirname, 'firebase-applet-config.json'),
    path.resolve(process.cwd(), 'firebase-applet-config.json'),
  ];

  for (const configPath of candidatePaths) {
    try {
      if (fs.existsSync(configPath)) {
        const parsed = JSON.parse(fs.readFileSync(configPath, 'utf8')) as FirebaseAppletConfig;
        cachedFirebaseConfig = {
          projectId: envProjectId || parsed.projectId,
          firestoreDatabaseId: envDbId || parsed.firestoreDatabaseId,
        };
        return cachedFirebaseConfig;
      }
    } catch {
      // Ignore missing/invalid config file
    }
  }

  cachedFirebaseConfig = {
    ...(envProjectId ? { projectId: envProjectId } : {}),
    ...(envDbId ? { firestoreDatabaseId: envDbId } : {}),
  };
  return cachedFirebaseConfig;
}

export interface ServerSiteSettings {
  siteName: string;
  metaTitle: string;
  metaDescription: string;
  faviconUrl: string;
  ogImageUrl: string;
  canonicalUrl: string;
  googleSiteVerification: string;
  googleHtmlFileName: string;
  googleHtmlFileContent: string;
}

const DEFAULT_SERVER_SITE_SETTINGS: ServerSiteSettings = {
  siteName: 'ClipIndex',
  metaTitle: 'ClipIndex — Video Timestamps, Summaries & Searchable Library',
  metaDescription:
    'Extract timestamped segments, AI summaries, transcripts, links, and searchable tags from shared videos, screenshots, and web pages.',
  faviconUrl: '',
  ogImageUrl: '',
  canonicalUrl: '',
  googleSiteVerification: '',
  googleHtmlFileName: '',
  googleHtmlFileContent: '',
};

let siteSettingsCache: { data: ServerSiteSettings; expiresAt: number } | null = null;

function readFirestoreStringField(
  fields: Record<string, { stringValue?: string } | undefined> | undefined,
  key: string
): string {
  return typeof fields?.[key]?.stringValue === 'string' ? fields[key]!.stringValue! : '';
}

function sanitizeServerHttpUrl(raw: string): string {
  const trimmed = (raw || '').trim();
  if (!trimmed) return '';
  try {
    const parsed = new URL(trimmed);
    return parsed.protocol === 'https:' || parsed.protocol === 'http:' ? parsed.toString() : '';
  } catch {
    return '';
  }
}

export async function getPublicSiteSettings(): Promise<ServerSiteSettings> {
  const now = Date.now();
  if (siteSettingsCache && siteSettingsCache.expiresAt > now) {
    return siteSettingsCache.data;
  }

  const cfg = getFirebaseAppletConfig();
  if (!cfg.projectId || !cfg.firestoreDatabaseId) {
    return DEFAULT_SERVER_SITE_SETTINGS;
  }

  try {
    const endpoint = `https://firestore.googleapis.com/v1/projects/${encodeURIComponent(
      cfg.projectId
    )}/databases/${encodeURIComponent(cfg.firestoreDatabaseId)}/documents/settings/site`;
    const res = await fetchWithTimeout(endpoint, 2500);
    if (!res.ok) {
      siteSettingsCache = { data: DEFAULT_SERVER_SITE_SETTINGS, expiresAt: now + 15000 };
      return DEFAULT_SERVER_SITE_SETTINGS;
    }
    const docJson = (await res.json()) as {
      fields?: Record<string, { stringValue?: string } | undefined>;
    };
    const f = docJson.fields;
    const siteName = readFirestoreStringField(f, 'siteName') || DEFAULT_SERVER_SITE_SETTINGS.siteName;
    const data: ServerSiteSettings = {
      siteName,
      metaTitle: readFirestoreStringField(f, 'metaTitle') || `${siteName} — Video Timestamps & Summaries`,
      metaDescription:
        readFirestoreStringField(f, 'metaDescription') || DEFAULT_SERVER_SITE_SETTINGS.metaDescription,
      faviconUrl: sanitizeServerHttpUrl(readFirestoreStringField(f, 'faviconUrl')),
      ogImageUrl: sanitizeServerHttpUrl(readFirestoreStringField(f, 'ogImageUrl')),
      canonicalUrl: sanitizeServerHttpUrl(readFirestoreStringField(f, 'canonicalUrl')),
      googleSiteVerification: readFirestoreStringField(f, 'googleSiteVerification').replace(
        /[^a-zA-Z0-9_-]/g,
        ''
      ),
      googleHtmlFileName: readFirestoreStringField(f, 'googleHtmlFileName'),
      googleHtmlFileContent: readFirestoreStringField(f, 'googleHtmlFileContent'),
    };
    siteSettingsCache = { data, expiresAt: now + 15000 };
    return data;
  } catch {
    return siteSettingsCache?.data || DEFAULT_SERVER_SITE_SETTINGS;
  }
}

function escapeHtmlAttr(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function injectSiteMetaIntoHtml(
  html: string,
  settings: ServerSiteSettings,
  requestOrigin: string
): string {
  const safeTitle = escapeHtmlAttr(settings.metaTitle || settings.siteName || 'ClipIndex');
  const safeDesc = escapeHtmlAttr(settings.metaDescription);
  const safeSiteName = escapeHtmlAttr(settings.siteName || 'ClipIndex');

  let updated = html
    .replace(/<title>[\s\S]*?<\/title>/i, `<title>${safeTitle}</title>`)
    .replace(
      /<meta\s+name=["']description["'][\s\S]*?\/?>/i,
      `<meta name="description" content="${safeDesc}" />`
    )
    .replace(
      /<meta\s+property=["']og:title["'][\s\S]*?\/?>/i,
      `<meta property="og:title" content="${safeTitle}" />`
    )
    .replace(
      /<meta\s+property=["']og:description["'][\s\S]*?\/?>/i,
      `<meta property="og:description" content="${safeDesc}" />`
    )
    .replace(
      /<meta\s+name=["']apple-mobile-web-app-title["'][\s\S]*?\/?>/i,
      `<meta name="apple-mobile-web-app-title" content="${safeSiteName}" />`
    );

  const extraTags: string[] = [`<meta property="og:site_name" content="${safeSiteName}" />`];

  if (settings.googleSiteVerification) {
    extraTags.push(
      `<meta name="google-site-verification" content="${escapeHtmlAttr(
        settings.googleSiteVerification
      )}" />`
    );
  }
  if (settings.ogImageUrl) {
    const safeOgImg = escapeHtmlAttr(settings.ogImageUrl);
    extraTags.push(`<meta property="og:image" content="${safeOgImg}" />`);
    extraTags.push(`<meta name="twitter:image" content="${safeOgImg}" />`);
  }
  const canonicalBase = settings.canonicalUrl || sanitizeServerHttpUrl(requestOrigin);
  if (canonicalBase) {
    extraTags.push(`<link rel="canonical" href="${escapeHtmlAttr(canonicalBase)}" />`);
  }
  if (settings.faviconUrl) {
    const safeFav = escapeHtmlAttr(settings.faviconUrl);
    updated = updated.replace(
      /<link\s+rel=["']icon["'][^>]*>/i,
      `<link rel="icon" href="${safeFav}" />`
    );
    updated = updated.replace(
      /<link\s+rel=["']apple-touch-icon["'][^>]*>/i,
      `<link rel="apple-touch-icon" href="${safeFav}" />`
    );
  }

  return updated.replace('</head>', `    ${extraTags.join('\n    ')}\n  </head>`);
}

function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured on the server.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      timeout: 16000,
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function extractCanonicalUrl(rawInput: string): string {
  const trimmed = (rawInput || '').trim();
  const urlMatch = trimmed.match(/https?:\/\/[^\s<>"'`]+/i);
  if (urlMatch) {
    return urlMatch[0].replace(/[),.;!?]+$/, '');
  }
  if (/^[a-z0-9.-]+\.[a-z]{2,}(\/|$)/i.test(trimmed)) {
    return `https://${trimmed}`;
  }
  return trimmed;
}

function detectPlatform(url: string): VideoPlatform {
  const lower = url.toLowerCase();
  if (lower.includes('youtube.com') || lower.includes('youtu.be')) return 'youtube';
  if (lower.includes('tiktok.com')) return 'tiktok';
  if (lower.includes('instagram.com') || lower.includes('instagr.am')) return 'instagram';
  if (lower.includes('facebook.com') || lower.includes('fb.watch') || lower.includes('fb.com')) return 'facebook';
  if (lower.includes('vimeo.com')) return 'vimeo';
  if (lower.includes('twitter.com') || lower.includes('x.com')) return 'x';
  return 'web';
}

function classifyUrlItemType(
  url: string,
  platform: VideoPlatform,
  modeHint?: string
): InboxItemType {
  if (modeHint === 'link') return 'link';
  if (modeHint === 'video') return 'video';
  if (platform === 'youtube' || platform === 'tiktok' || platform === 'vimeo') {
    return 'video';
  }
  if (platform === 'instagram' || platform === 'facebook' || platform === 'x') {
    const lower = url.toLowerCase();
    if (
      lower.includes('/reel') ||
      lower.includes('/watch') ||
      lower.includes('/video') ||
      lower.includes('/tv/') ||
      lower.includes('fb.watch') ||
      lower.includes('/status/')
    ) {
      return 'video';
    }
    return 'video';
  }
  return 'link';
}

const NOISY_LINK_HOSTS = [
  'www.w3.org',
  'schema.org',
  'fonts.googleapis.com',
  'fonts.gstatic.com',
  'i.ytimg.com',
  'yt3.ggpht.com',
  'static.xx.fbcdn.net',
];

function extractUrlsFromText(text: string, excludeUrl = ''): string[] {
  if (!text) return [];
  const matches = text.match(/https?:\/\/[^\s<>"'`)\]]+/gi) || [];
  const seen = new Set<string>();
  const normalizedExclude = excludeUrl.trim().toLowerCase();
  const out: string[] = [];

  for (const raw of matches) {
    const cleaned = raw.replace(/[.,;:!?]+$/, '');
    try {
      const parsed = new URL(cleaned);
      if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') continue;
      if (NOISY_LINK_HOSTS.includes(parsed.hostname.toLowerCase())) continue;
      if (/\.(js|css|woff2?|png|jpe?g|gif|webp|svg|ico)(\?|$)/i.test(parsed.pathname)) continue;
      const key = parsed.toString().toLowerCase();
      if (key === normalizedExclude || seen.has(key)) continue;
      seen.add(key);
      out.push(parsed.toString().slice(0, 1000));
      if (out.length >= 25) break;
    } catch {
      // Ignore malformed URLs
    }
  }
  return out;
}

function extractReadableTextFromHtml(html: string): string {
  const withoutScripts = html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, ' ')
    .replace(/<svg[\s\S]*?<\/svg>/gi, ' ');
  const textOnly = decodeHtmlEntities(withoutScripts.replace(/<[^>]+>/g, ' '))
    .replace(/\s+/g, ' ')
    .trim();
  return textOnly.slice(0, 6000);
}

function extractAnchorLinksFromHtml(html: string, baseUrl: string): ExtractedLink[] {
  const results: ExtractedLink[] = [];
  const seen = new Set<string>();
  let baseOrigin = '';
  try {
    baseOrigin = new URL(baseUrl).origin;
  } catch {
    baseOrigin = '';
  }

  const anchorRegex = /<a[^>]+href=["']([^"'#]+)["'][^>]*>([\s\S]*?)<\/a>/gi;
  let m: RegExpExecArray | null;
  while ((m = anchorRegex.exec(html)) !== null) {
    const rawHref = decodeHtmlEntities(m[1]).trim();
    if (!rawHref || /^(javascript|mailto|tel|data):/i.test(rawHref)) continue;
    let resolved = '';
    try {
      resolved = new URL(rawHref, baseUrl).toString();
    } catch {
      continue;
    }
    if (!/^https?:\/\//i.test(resolved)) continue;
    const key = resolved.toLowerCase();
    if (seen.has(key) || key === baseUrl.toLowerCase()) continue;
    const label = decodeHtmlEntities(m[2].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim()).slice(0, 120);
    if (!label && resolved.startsWith(baseOrigin)) continue;
    seen.add(key);
    results.push({
      url: resolved.slice(0, 1000),
      label: label || new URL(resolved).hostname,
      kind: 'resource',
    });
    if (results.length >= 20) break;
  }
  return results;
}

function extractYouTubeId(url: string): string | null {
  try {
    const parsed = new URL(url);
    if (parsed.hostname.includes('youtu.be')) {
      return parsed.pathname.split('/').filter(Boolean)[0] || null;
    }
    if (parsed.pathname.includes('/shorts/')) {
      return parsed.pathname.split('/shorts/')[1]?.split('/')[0] || null;
    }
    if (parsed.pathname.includes('/embed/')) {
      return parsed.pathname.split('/embed/')[1]?.split('/')[0] || null;
    }
    if (parsed.pathname.includes('/live/')) {
      return parsed.pathname.split('/live/')[1]?.split('/')[0] || null;
    }
    return parsed.searchParams.get('v');
  } catch {
    return null;
  }
}

function formatSeconds(sec: number): string {
  const safe = Math.max(0, Math.floor(sec));
  const hrs = Math.floor(safe / 3600);
  const mins = Math.floor((safe % 3600) / 60);
  const rem = safe % 60;
  if (hrs > 0) {
    return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(rem).padStart(2, '0')}`;
  }
  return `${String(mins).padStart(2, '0')}:${String(rem).padStart(2, '0')}`;
}

function parseTimestampToSeconds(ts: string): number {
  const parts = ts
    .trim()
    .split(':')
    .map((p) => Number(p))
    .filter((n) => !Number.isNaN(n));
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  if (parts.length === 1) return parts[0];
  return 0;
}

function decodeHtmlEntities(str: string): string {
  return str
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&apos;/g, "'");
}

interface FetchedMetadata {
  title: string;
  creator: string;
  thumbnailUrl: string;
  description: string;
  captionsText: string;
  pageText: string;
  extractedLinks: ExtractedLink[];
  durationSeconds: number;
  metadataSource: string;
}

async function fetchWithTimeout(url: string, timeoutMs = 5000): Promise<globalThis.Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, {
      signal: controller.signal,
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
        Accept: 'text/html,application/json,application/xhtml+xml',
      },
      redirect: 'follow',
    });
  } finally {
    clearTimeout(timer);
  }
}

async function fetchPlatformMetadata(url: string, platform: VideoPlatform): Promise<FetchedMetadata> {
  const result: FetchedMetadata = {
    title: '',
    creator: '',
    thumbnailUrl: '',
    description: '',
    captionsText: '',
    pageText: '',
    extractedLinks: [],
    durationSeconds: 0,
    metadataSource: 'url-grounding',
  };

  if (!isSafePublicHttpUrl(url)) {
    return result;
  }

  try {
    if (platform === 'youtube') {
      const ytId = extractYouTubeId(url);
      if (ytId) {
        result.thumbnailUrl = `https://img.youtube.com/vi/${ytId}/hqdefault.jpg`;
      }

      const [oembedOutcome, pageOutcome] = await Promise.allSettled([
        fetchWithTimeout(
          `https://www.youtube.com/oembed?url=${encodeURIComponent(url)}&format=json`,
          3500
        ),
        fetchWithTimeout(url, 4000),
      ]);

      if (oembedOutcome.status === 'fulfilled' && oembedOutcome.value.ok) {
        try {
          const data = (await oembedOutcome.value.json()) as {
            title?: string;
            author_name?: string;
            thumbnail_url?: string;
          };
          result.title = data.title || result.title;
          result.creator = data.author_name || result.creator;
          result.thumbnailUrl = data.thumbnail_url || result.thumbnailUrl;
          result.metadataSource = 'youtube-oembed';
        } catch {
          // Ignore malformed oEmbed JSON
        }
      }

      if (pageOutcome.status === 'fulfilled' && pageOutcome.value.ok) {
        try {
          const html = await pageOutcome.value.text();
          const descMatch = html.match(/"shortDescription":"((?:[^"\\]|\\.)*)"/);
          if (descMatch?.[1]) {
            result.description = JSON.parse(`"${descMatch[1]}"`) as string;
          }
          const lenMatch = html.match(/"lengthSeconds":"(\d+)"/);
          if (lenMatch?.[1]) {
            result.durationSeconds = Number(lenMatch[1]) || 0;
          }
          const captionMatch = html.match(/"captionTracks":\[\{"baseUrl":"(https:[^"]+)"/);
          if (captionMatch?.[1]) {
            const captionUrl = captionMatch[1].replace(/\\u0026/g, '&');
            const capRes = await fetchWithTimeout(captionUrl, 3500);
            if (capRes.ok) {
              const xml = await capRes.text();
              const lines: string[] = [];
              const textRegex = /<text start="([^"]+)"[^>]*>([\s\S]*?)<\/text>/g;
              let m: RegExpExecArray | null;
              while ((m = textRegex.exec(xml)) !== null) {
                const startSec = Number(m[1]) || 0;
                const cleanText = decodeHtmlEntities(m[2].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim());
                if (cleanText) {
                  lines.push(`[${formatSeconds(startSec)}] ${cleanText}`);
                }
                if (lines.length >= 250) break;
              }
              if (lines.length > 0) {
                result.captionsText = lines.join('\n');
                result.metadataSource = 'youtube-captions';
              }
            }
          }
        } catch {
          // Ignore watch-page parse failures; oEmbed and Gemini grounding continue
        }
      }
      return result;
    }

    if (platform === 'tiktok') {
      try {
        const oembedRes = await fetchWithTimeout(
          `https://www.tiktok.com/oembed?url=${encodeURIComponent(url)}`,
          4500
        );
        if (oembedRes.ok) {
          const data = (await oembedRes.json()) as {
            title?: string;
            author_name?: string;
            thumbnail_url?: string;
          };
          result.title = data.title || '';
          result.creator = data.author_name || '';
          result.thumbnailUrl = data.thumbnail_url || '';
          result.metadataSource = 'tiktok-oembed';
          return result;
        }
      } catch {
        // Continue to OpenGraph fallback
      }
    }

    if (platform === 'vimeo') {
      try {
        const oembedRes = await fetchWithTimeout(
          `https://vimeo.com/api/oembed.json?url=${encodeURIComponent(url)}`,
          4500
        );
        if (oembedRes.ok) {
          const data = (await oembedRes.json()) as {
            title?: string;
            author_name?: string;
            thumbnail_url?: string;
            description?: string;
            duration?: number;
          };
          result.title = data.title || '';
          result.creator = data.author_name || '';
          result.thumbnailUrl = data.thumbnail_url || '';
          result.description = data.description || '';
          result.durationSeconds = data.duration || 0;
          result.metadataSource = 'vimeo-oembed';
          return result;
        }
      } catch {
        // Continue to OpenGraph fallback
      }
    }

    // OpenGraph + readable text + link fallback for Web links, Instagram, Facebook, X
    const pageRes = await fetchWithTimeout(url, 4500);
    if (pageRes.ok) {
      const html = await pageRes.text();
      const ogTitle =
        html.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i)?.[1] ||
        html.match(/<title[^>]*>([^<]+)<\/title>/i)?.[1] ||
        '';
      const ogDesc =
        html.match(/<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']+)["']/i)?.[1] ||
        html.match(/<meta[^>]+name=["']description["'][^>]+content=["']([^"']+)["']/i)?.[1] ||
        '';
      const ogImage =
        html.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i)?.[1] || '';
      const ogSite =
        html.match(/<meta[^>]+property=["']og:site_name["'][^>]+content=["']([^"']+)["']/i)?.[1] || '';

      if (ogTitle) {
        result.title = decodeHtmlEntities(ogTitle).trim();
        result.metadataSource = 'opengraph-meta';
      }
      if (ogSite) result.creator = decodeHtmlEntities(ogSite).trim();
      if (ogDesc) result.description = decodeHtmlEntities(ogDesc).trim();
      if (ogImage) result.thumbnailUrl = decodeHtmlEntities(ogImage).trim();

      result.pageText = extractReadableTextFromHtml(html);
      result.extractedLinks = extractAnchorLinksFromHtml(html, url);
    }
  } catch {
    // Non-fatal; Gemini URL context + search grounding handles metadata discovery
  }

  return result;
}

const analysisResponseSchema = {
  type: Type.OBJECT,
  properties: {
    title: { type: Type.STRING, description: 'Clear, descriptive title for the video, screenshot, or web/product link.' },
    creator: { type: Type.STRING, description: 'Creator, channel, brand, or website name.' },
    durationLabel: { type: Type.STRING, description: 'Duration like 03:45 for videos, or type label like Screenshot / Product Page.' },
    category: { type: Type.STRING, description: 'Primary topic category (1-3 words, e.g. Software, Shopping, Marketing, Design).' },
    summary: { type: Type.STRING, description: 'Concise 2-4 sentence executive summary.' },
    tldrBullets: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: '3 to 6 crisp, actionable takeaway bullet points.',
    },
    tags: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: '5 to 10 lowercase searchable topic tags without # prefix.',
    },
    segments: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          timestamp: { type: Type.STRING, description: 'Timestamp formatted MM:SS or section marker like 00:00.' },
          seconds: { type: Type.INTEGER, description: 'Numeric offset in seconds (or sequential index for screenshots/pages).' },
          title: { type: Type.STRING, description: 'Short chapter/section heading.' },
          summary: { type: Type.STRING, description: '1-2 sentence explanation of this segment or page section.' },
          keyQuote: { type: Type.STRING, description: 'Notable quote, price, or key phrase from this section, if any.' },
        },
        required: ['timestamp', 'seconds', 'title', 'summary'],
      },
      description: '3 to 12 chronological key segments or visual/page sections.',
    },
    transcript: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          timestamp: { type: Type.STRING, description: 'Timestamp formatted MM:SS.' },
          seconds: { type: Type.INTEGER, description: 'Numeric offset in seconds.' },
          speaker: { type: Type.STRING, description: 'Speaker, OCR Region, or Section name.' },
          text: { type: Type.STRING, description: 'Spoken transcript line, OCR extracted text, or key factual details.' },
        },
        required: ['timestamp', 'seconds', 'text'],
      },
      description: 'Chronological timestamped transcript, screenshot OCR text lines, or webpage facts.',
    },
    links: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          url: { type: Type.STRING, description: 'Full valid https:// or http:// URL mentioned, shown on screen, or found in description.' },
          label: { type: Type.STRING, description: 'Short human-readable name of the product, service, tool, or resource.' },
          kind: { type: Type.STRING, description: 'One of: product, service, resource, social, other.' },
          context: { type: Type.STRING, description: 'Brief context on why this link was mentioned or what it offers.' },
        },
        required: ['url', 'label'],
      },
      description: 'Any URLs, product links, service websites, or resources retrieved from the video/screenshot/page.',
    },
  },
  required: ['title', 'creator', 'durationLabel', 'category', 'summary', 'tldrBullets', 'tags', 'segments', 'transcript'],
};

function mergeExtractedLinks(
  aiLinks: unknown,
  fallbackUrls: ExtractedLink[]
): ExtractedLink[] {
  const seen = new Set<string>();
  const merged: ExtractedLink[] = [];

  const pushLink = (candidate: { url?: unknown; label?: unknown; kind?: unknown; context?: unknown }) => {
    if (typeof candidate.url !== 'string') return;
    let trimmed = candidate.url.trim();
    if (!/^https?:\/\//i.test(trimmed)) {
      if (/^[a-z0-9.-]+\.[a-z]{2,}(\/|$)/i.test(trimmed)) {
        trimmed = `https://${trimmed}`;
      } else {
        return;
      }
    }
    try {
      const parsed = new URL(trimmed);
      if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return;
      if (NOISY_LINK_HOSTS.includes(parsed.hostname.toLowerCase())) return;
      const key = parsed.toString().toLowerCase();
      if (seen.has(key)) return;
      seen.add(key);
      const rawKind = String(candidate.kind || '').toLowerCase();
      const kind: ExtractedLink['kind'] =
        rawKind === 'product' || rawKind === 'service' || rawKind === 'resource' || rawKind === 'social'
          ? rawKind
          : 'other';
      merged.push({
        url: parsed.toString().slice(0, 1000),
        label: String(candidate.label || parsed.hostname).trim().slice(0, 140),
        kind,
        ...(candidate.context ? { context: String(candidate.context).trim().slice(0, 260) } : {}),
      });
    } catch {
      // Ignore invalid URL
    }
  };

  if (Array.isArray(aiLinks)) {
    for (const item of aiLinks) {
      if (item && typeof item === 'object') {
        pushLink(item as Record<string, unknown>);
      }
      if (merged.length >= 30) break;
    }
  }

  for (const fb of fallbackUrls) {
    if (merged.length >= 30) break;
    pushLink(fb);
  }

  return merged;
}

function normalizeAnalysisPayload(
  raw: Record<string, unknown>,
  fallbackTitle: string,
  fallbackCreator: string,
  fallbackDuration: string,
  fallbackLinks: ExtractedLink[] = []
): Omit<AnalyzeVideoResponse, 'url' | 'platform' | 'thumbnailUrl' | 'metadataSource' | 'itemType'> {
  const rawSegments = Array.isArray(raw.segments) ? raw.segments : [];
  const segments: VideoSegment[] = rawSegments
    .slice(0, 60)
    .map((s) => {
      const obj = (s && typeof s === 'object' ? s : {}) as Record<string, unknown>;
      const rawTs = typeof obj.timestamp === 'string' && obj.timestamp.trim() ? obj.timestamp.trim() : '00:00';
      const seconds =
        typeof obj.seconds === 'number' && Number.isFinite(obj.seconds)
          ? Math.max(0, Math.floor(obj.seconds))
          : parseTimestampToSeconds(rawTs);
      return {
        timestamp: formatSeconds(seconds),
        seconds,
        title: String(obj.title || 'Key Moment').slice(0, 140),
        summary: String(obj.summary || '').slice(0, 600),
        ...(obj.keyQuote ? { keyQuote: String(obj.keyQuote).slice(0, 280) } : {}),
      };
    })
    .sort((a, b) => a.seconds - b.seconds);

  const rawTranscript = Array.isArray(raw.transcript) ? raw.transcript : [];
  const transcript: TranscriptEntry[] = rawTranscript
    .slice(0, 200)
    .map((t) => {
      const obj = (t && typeof t === 'object' ? t : {}) as Record<string, unknown>;
      const rawTs = typeof obj.timestamp === 'string' && obj.timestamp.trim() ? obj.timestamp.trim() : '00:00';
      const seconds =
        typeof obj.seconds === 'number' && Number.isFinite(obj.seconds)
          ? Math.max(0, Math.floor(obj.seconds))
          : parseTimestampToSeconds(rawTs);
      return {
        timestamp: formatSeconds(seconds),
        seconds,
        speaker: obj.speaker ? String(obj.speaker).slice(0, 60) : 'Speaker',
        text: String(obj.text || '').slice(0, 800),
      };
    })
    .filter((entry) => entry.text.length > 0)
    .sort((a, b) => a.seconds - b.seconds);

  const tldrBullets = (Array.isArray(raw.tldrBullets) ? raw.tldrBullets : [])
    .map((b) => String(b).trim())
    .filter(Boolean)
    .slice(0, 10);

  const tags = Array.from(
    new Set(
      (Array.isArray(raw.tags) ? raw.tags : [])
        .map((t) => String(t).trim().toLowerCase().replace(/^#/, ''))
        .filter((t) => t.length > 0 && t.length <= 40)
    )
  ).slice(0, 15);

  const links = mergeExtractedLinks(raw.links, fallbackLinks);

  return {
    title: String(raw.title || fallbackTitle || 'Untitled Item').slice(0, 300),
    creator: String(raw.creator || fallbackCreator || 'Creator').slice(0, 150),
    durationLabel: String(raw.durationLabel || fallbackDuration || '—').slice(0, 32),
    category: String(raw.category || 'General').slice(0, 80),
    summary: String(raw.summary || 'Summary generated from shared source.').slice(0, 5000),
    tldrBullets,
    tags,
    segments,
    transcript,
    links,
  };
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function isTransientGeminiError(err: unknown): boolean {
  const msg = (err instanceof Error ? err.message : String(err)).toLowerCase();
  return (
    msg.includes('503') ||
    msg.includes('unavailable') ||
    msg.includes('high demand') ||
    msg.includes('overloaded') ||
    msg.includes('502') ||
    msg.includes('504') ||
    msg.includes('timeout') ||
    msg.includes('timed out') ||
    msg.includes('aborted') ||
    msg.includes('fetch failed') ||
    msg.includes('econnreset') ||
    msg.includes('etimedout')
  );
}

let primaryCooldownUntil = 0;

async function generateWithRetryAndFallback<T>(
  runner: (model: string, isFallback: boolean) => Promise<T>
): Promise<T> {
  const now = Date.now();
  let lastError: unknown;

  if (now >= primaryCooldownUntil) {
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        return await runner(GEMINI_MODEL, false);
      } catch (err) {
        lastError = err;
        if (!isTransientGeminiError(err)) {
          throw err;
        }
        if (attempt === 0) {
          await sleep(400 + Math.floor(Math.random() * 200));
        }
      }
    }
    primaryCooldownUntil = Date.now() + 120_000;
    console.warn(`[Gemini] ${GEMINI_MODEL} returned transient 503/timeout; switching to ${GEMINI_FALLBACK_MODEL} for 120s.`);
  }

  try {
    return await runner(GEMINI_FALLBACK_MODEL, true);
  } catch (fallbackErr) {
    if (isTransientGeminiError(fallbackErr)) {
      await sleep(500);
      return await runner(GEMINI_FALLBACK_MODEL, true);
    }
    throw fallbackErr || lastError;
  }
}

function formatGeminiError(err: unknown): { status: number; message: string } {
  const rawMsg = err instanceof Error ? err.message : String(err);
  let msg = rawMsg;

  try {
    const jsonStart = rawMsg.indexOf('{');
    if (jsonStart >= 0) {
      const parsed = JSON.parse(rawMsg.slice(jsonStart)) as {
        error?: { message?: string; status?: string; code?: number };
      };
      if (parsed?.error?.message) {
        msg = parsed.error.message;
      }
    }
  } catch {
    // Keep rawMsg if not JSON
  }

  const lower = `${rawMsg} ${msg}`.toLowerCase();
  if (rawMsg.includes('503') || rawMsg.includes('UNAVAILABLE') || lower.includes('high demand') || lower.includes('overloaded')) {
    return {
      status: 503,
      message:
        'Gemini AI is temporarily experiencing high demand (503). Please wait a few seconds and try again.',
    };
  }
  if (lower.includes('timeout') || lower.includes('timed out') || lower.includes('aborted')) {
    return {
      status: 504,
      message:
        'Gemini AI took too long to respond while inspecting this video. Please try again in a few seconds.',
    };
  }
  if (rawMsg.includes('403') || rawMsg.includes('PERMISSION_DENIED')) {
    return {
      status: 403,
      message: 'Gemini API permission denied. Please verify your API key in Settings > Secrets.',
    };
  }
  if (rawMsg.includes('429') || rawMsg.includes('RESOURCE_EXHAUSTED')) {
    return {
      status: 429,
      message: 'Gemini API rate or quota limit reached. Please retry shortly or check your quota in Settings > Secrets.',
    };
  }
  if (rawMsg.includes('API_KEY_INVALID') || rawMsg.includes('GEMINI_API_KEY')) {
    return {
      status: 400,
      message: 'Gemini API key is missing or invalid. Please check Settings > Secrets.',
    };
  }
  return { status: 500, message: msg || 'Failed to analyze video.' };
}

function resolveAllowedOrigins(): string[] {
  const raw = [process.env.CORS_ORIGIN || '', process.env.APP_URL || '']
    .join(',')
    .split(',')
    .map((s) => s.trim().replace(/\/+$/, ''))
    .filter(Boolean);
  return Array.from(new Set(raw));
}

export function createApiApp(): express.Express {
  const app = express();
  app.use(express.json({ limit: '45mb' }));

  // Optional CORS support when frontend (e.g., Vercel) calls backend on another origin (e.g., Render)
  app.use((req: Request, res: Response, next: NextFunction) => {
    const requestOrigin = req.headers.origin;
    if (requestOrigin) {
      const allowedOrigins = resolveAllowedOrigins();
      const normalizedOrigin = requestOrigin.replace(/\/+$/, '');
      const isAllowed =
        allowedOrigins.includes('*') ||
        allowedOrigins.includes(normalizedOrigin) ||
        normalizedOrigin.endsWith('.vercel.app') ||
        normalizedOrigin === 'http://localhost:3000' ||
        normalizedOrigin === 'http://localhost:5173';

      if (isAllowed) {
        res.setHeader('Access-Control-Allow-Origin', requestOrigin);
        res.setHeader('Vary', 'Origin');
        res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
      }
    }

    if (req.method === 'OPTIONS') {
      res.status(204).end();
      return;
    }
    next();
  });

  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({
      ok: true,
      geminiConfigured: Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim()),
      model: GEMINI_MODEL,
    });
  });

  app.get('/api/usage', async (req: Request, res: Response) => {
    const cfg = getFirebaseAppletConfig();
    const caller = await verifyCallerIdentity(req, cfg.projectId);
    res.json(getCallerUsageSnapshot(caller));
  });

  app.post('/api/site-settings/invalidate', (_req: Request, res: Response) => {
    siteSettingsCache = null;
    res.json({ ok: true });
  });

  app.get(/^\/(google[a-zA-Z0-9]+\.html)$/, async (req: Request, res: Response, next) => {
    const requestedFile = req.path.replace(/^\/+/, '');
    const settings = await getPublicSiteSettings();
    if (settings.googleHtmlFileName && settings.googleHtmlFileName === requestedFile) {
      const content =
        settings.googleHtmlFileContent.trim() ||
        `google-site-verification: ${settings.googleHtmlFileName}`;
      res.status(200).type('text/plain; charset=utf-8').send(content);
      return;
    }
    next();
  });

  app.get('/robots.txt', async (req: Request, res: Response) => {
    const settings = await getPublicSiteSettings();
    const fallbackOrigin = `${req.protocol}://${req.get('host') || 'localhost:3000'}`;
    const baseUrl = (settings.canonicalUrl || process.env.APP_URL || fallbackOrigin).replace(/\/+$/, '');
    res
      .status(200)
      .type('text/plain; charset=utf-8')
      .send(`User-agent: *\nAllow: /\nSitemap: ${baseUrl}/sitemap.xml\n`);
  });

  app.get('/sitemap.xml', async (req: Request, res: Response) => {
    const settings = await getPublicSiteSettings();
    const fallbackOrigin = `${req.protocol}://${req.get('host') || 'localhost:3000'}`;
    const baseUrl = (settings.canonicalUrl || process.env.APP_URL || fallbackOrigin).replace(/\/+$/, '');
    const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n  <url>\n    <loc>${escapeHtmlAttr(baseUrl)}/</loc>\n    <changefreq>daily</changefreq>\n    <priority>1.0</priority>\n  </url>\n</urlset>\n`;
    res.status(200).type('application/xml; charset=utf-8').send(xml);
  });

  app.post('/api/analyze-video', async (req: Request, res: Response) => {
    let releaseGuard: (() => void) | undefined;
    try {
      const {
        url: inputUrl,
        rawShareText,
        title: hintedTitle,
        customFocus,
        saveReason,
        userNote,
        modeHint,
        fileData,
        aiSettings,
      } = req.body as {
        url?: string;
        rawShareText?: string;
        title?: string;
        customFocus?: string;
        saveReason?: string;
        userNote?: string;
        modeHint?: 'auto' | 'video' | 'screenshot' | 'link';
        fileData?: { mimeType: string; base64: string; fileName?: string };
        aiSettings?: Partial<AiBrainSettings>;
      };

      // Validate input sizes before touching Gemini
      if ((inputUrl && inputUrl.length > 2048) || (rawShareText && rawShareText.length > 4096)) {
        res.status(400).json({ error: 'Input URL or share text is too long (max 2,048 characters).' });
        return;
      }
      if ((userNote && userNote.length > 1000) || (customFocus && customFocus.length > 500)) {
        res.status(400).json({ error: 'Note or focus text exceeds allowed length.' });
        return;
      }

      if (fileData?.base64) {
        const approxBytes = Math.ceil((fileData.base64.length * 3) / 4);
        const isImg = Boolean(fileData.mimeType?.startsWith('image/'));
        const maxBytes = isImg ? 6 * 1024 * 1024 : 20 * 1024 * 1024;
        if (approxBytes > maxBytes) {
          res.status(413).json({
            error: isImg
              ? 'Screenshot exceeds 6 MB limit. Please upload a smaller or compressed image.'
              : 'Uploaded clip exceeds 20 MB server analysis limit.',
          });
          return;
        }
      }

      const candidateUrl = !fileData?.base64 ? extractCanonicalUrl(inputUrl || rawShareText || '') : '';
      if (!fileData?.base64) {
        if (!candidateUrl || !/^https?:\/\//i.test(candidateUrl)) {
          res.status(400).json({
            error: 'Please provide a valid URL (video, product, service, or website) or upload a screenshot/clip.',
          });
          return;
        }
        if (!isSafePublicHttpUrl(candidateUrl)) {
          res.status(400).json({ error: 'Private, local, or invalid network URLs are not allowed.' });
          return;
        }
      }

      const cfg = getFirebaseAppletConfig();
      const caller = await verifyCallerIdentity(req, cfg.projectId);
      const fingerprint = fileData?.base64
        ? `file:${fileData.fileName || 'media'}:${fileData.base64.slice(0, 64)}`
        : `url:${candidateUrl.toLowerCase()}`;

      const guard = guardAiRequest(caller, 'analyze', res, fingerprint);
      if (!guard.allowed) {
        return;
      }
      releaseGuard = guard.release;

      const ai = getGeminiClient();
      const thinkingLevel =
        aiSettings?.depth === 'balanced' ? ThinkingLevel.MEDIUM : ThinkingLevel.LOW;
      const targetLanguage = aiSettings?.language?.slice(0, 60).trim();
      const adminGuidance = aiSettings?.customInstruction?.slice(0, 1000).trim();
      const reasonContext = [
        saveReason ? `Why the user saved this: ${saveReason.slice(0, 80)}` : '',
        userNote ? `User's personal note / context: ${userNote.slice(0, 1000)}` : '',
        customFocus ? `User focus area: ${customFocus.slice(0, 500)}` : '',
      ]
        .filter(Boolean)
        .join('\n');

      // Path 1: Uploaded Screenshot / Image (OCR, product/service detection, URL extraction)
      if (fileData?.base64 && fileData?.mimeType && fileData.mimeType.startsWith('image/')) {
        const fileName = fileData.fileName || 'Screenshot';
        const prompt = [
          `Inspect this screenshot/image (${fileName}) thoroughly for a Universal Share Inbox.`,
          reasonContext,
          adminGuidance ? `Workspace guidance: ${adminGuidance}` : '',
          targetLanguage && targetLanguage.toLowerCase() !== 'auto-detect'
            ? `Write summary, TL;DR bullets, section titles, and descriptions in ${targetLanguage}.`
            : '',
          `Instructions:`,
          `- Identify what the screenshot shows (e.g., product listing, service ad, WhatsApp/Messenger chat, UI, receipt, social post, article).`,
          `- Extract ALL visible text verbatim into 'transcript' lines (using sequential section markers like 00:00, 00:01, 00:02 and speaker set to the visual region like 'Header', 'Product Details', 'Pricing', 'Footer').`,
          `- Break down the visual sections into 'segments' so the user can scan what each part of the screenshot contains.`,
          `- Extract EVERY visible URL, website domain (convert bare domains like example.com/deal into https://example.com/deal), @handle link, or product/service link into 'links' with clear labels and kind ('product' | 'service' | 'resource' | 'social' | 'other').`,
          `- Generate 5-10 clean lowercase searchable tags (including brand names, product names, prices/keywords, and why-saved keywords).`,
          `- Set durationLabel to 'Screenshot'.`,
        ]
          .filter(Boolean)
          .join('\n');

        const response = await generateWithRetryAndFallback((model, isFallback) =>
          ai.models.generateContent({
            model,
            contents: {
              parts: [
                {
                  inlineData: {
                    mimeType: fileData.mimeType,
                    data: fileData.base64,
                  },
                },
                { text: prompt },
              ],
            },
            config: {
              thinkingConfig: {
                thinkingLevel: isFallback ? ThinkingLevel.LOW : thinkingLevel,
              },
              responseMimeType: 'application/json',
              responseSchema: analysisResponseSchema,
            },
          })
        );

        const parsed = JSON.parse((response.text ?? '{}').trim()) as Record<string, unknown>;
        const normalized = normalizeAnalysisPayload(
          parsed,
          hintedTitle || fileName,
          'Screenshot Capture',
          'Screenshot'
        );

        const payload: AnalyzeVideoResponse = {
          itemType: 'screenshot',
          url: `local://device/${encodeURIComponent(fileName)}`,
          platform: 'screenshot',
          thumbnailUrl: '',
          metadataSource: 'gemini-vision-ocr',
          ...normalized,
        };
        guard.recordSuccess?.();
        res.json(payload);
        return;
      }

      // Path 2: Direct uploaded video or audio file analysis (true multimodal inspection)
      if (fileData?.base64 && fileData?.mimeType) {
        const fileName = fileData.fileName || 'Uploaded Video';
        const prompt = [
          `Analyze this uploaded video/audio clip (${fileName}) thoroughly.`,
          reasonContext,
          adminGuidance ? `Workspace guidance: ${adminGuidance}` : '',
          targetLanguage && targetLanguage.toLowerCase() !== 'auto-detect'
            ? `Write summary, TL;DR bullets, segment titles, and descriptions in ${targetLanguage}.`
            : '',
          `Produce accurate chronological timestamped key segments, a detailed timestamped transcript of spoken dialogue/visual events, a concise summary, TL;DR bullets, category, searchable lowercase tags, AND extract any websites, products, services, or URLs mentioned or shown on screen into 'links'.`,
        ]
          .filter(Boolean)
          .join('\n');

        const response = await generateWithRetryAndFallback((model, isFallback) =>
          ai.models.generateContent({
            model,
            contents: {
              parts: [
                {
                  inlineData: {
                    mimeType: fileData.mimeType,
                    data: fileData.base64,
                  },
                },
                { text: prompt },
              ],
            },
            config: {
              thinkingConfig: {
                thinkingLevel: isFallback ? ThinkingLevel.LOW : thinkingLevel,
              },
              responseMimeType: 'application/json',
              responseSchema: analysisResponseSchema,
            },
          })
        );

        const parsed = JSON.parse((response.text ?? '{}').trim()) as Record<string, unknown>;
        const normalized = normalizeAnalysisPayload(parsed, hintedTitle || fileName, 'Local Device', 'Video Clip');

        const payload: AnalyzeVideoResponse = {
          itemType: 'video',
          url: `local://device/${encodeURIComponent(fileName)}`,
          platform: 'upload',
          thumbnailUrl: '',
          metadataSource: 'multimodal-video',
          ...normalized,
        };
        guard.recordSuccess?.();
        res.json(payload);
        return;
      }

      // Path 3: Shared URL analysis (Videos + Web / Product / Service Links)
      const canonicalUrl = candidateUrl;

      const platform = detectPlatform(canonicalUrl);
      const itemType = classifyUrlItemType(canonicalUrl, platform, modeHint);
      const meta = await fetchPlatformMetadata(canonicalUrl, platform);
      const fallbackTitle =
        meta.title ||
        hintedTitle ||
        (itemType === 'link' ? new URL(canonicalUrl).hostname : `${platform.toUpperCase()} Video`);
      const fallbackDuration =
        meta.durationSeconds > 0
          ? formatSeconds(meta.durationSeconds)
          : itemType === 'link'
            ? 'Web Page'
            : '—';

      const researchPrompt =
        itemType === 'link'
          ? [
              `Inspect and analyze this shared web/product/service link: ${canonicalUrl}`,
              hintedTitle ? `Share title: ${hintedTitle}` : '',
              meta.title ? `Page title: ${meta.title}` : '',
              meta.creator ? `Site/Brand: ${meta.creator}` : '',
              meta.description ? `Meta description:\n${meta.description.slice(0, 2000)}` : '',
              meta.pageText ? `Fetched webpage content:\n${meta.pageText.slice(0, 5000)}` : '',
              reasonContext,
              `Extract product/service details, pricing or key offering, main sections, important links (buy/signup/docs/social), and searchable keywords.`,
            ]
              .filter(Boolean)
              .join('\n\n')
          : [
              `Inspect and analyze this shared ${platform} video link: ${canonicalUrl}`,
              hintedTitle ? `Share sheet title: ${hintedTitle}` : '',
              meta.title ? `Fetched title: ${meta.title}` : '',
              meta.creator ? `Fetched creator/channel: ${meta.creator}` : '',
              meta.durationSeconds > 0
                ? `Known duration: ${formatSeconds(meta.durationSeconds)} (${meta.durationSeconds} seconds)`
                : '',
              meta.description ? `Fetched description/caption:\n${meta.description.slice(0, 3000)}` : '',
              meta.captionsText ? `Fetched timestamped captions:\n${meta.captionsText.slice(0, 12000)}` : '',
              reasonContext,
              `Extract all factual details about this video: exact topic, speaker/creator, key chapters with accurate timestamps (if short-form < 90s, segment by 00:00, 00:15, 00:30, etc.; if long-form, use chapter/caption timestamps), key takeaways, transcript/spoken flow, mentioned links/products/services, and searchable tags.`,
            ]
              .filter(Boolean)
              .join('\n\n');

      let groundedNotes = '';
      const hasRichLocalPageContent =
        itemType === 'link' && Boolean(meta.title) && meta.pageText.length >= 600;

      if (!meta.captionsText && !hasRichLocalPageContent) {
        try {
          const groundedRes = await generateWithRetryAndFallback((model) =>
            ai.models.generateContent({
              model,
              contents: researchPrompt,
              config: {
                thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
                tools: [{ urlContext: {} }, { googleSearch: {} }],
              },
            })
          );
          groundedNotes = groundedRes.text || '';
        } catch (groundErr) {
          if (!isTransientGeminiError(groundErr)) {
            try {
              const searchRes = await generateWithRetryAndFallback((model) =>
                ai.models.generateContent({
                  model,
                  contents: researchPrompt,
                  config: {
                    thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
                    tools: [{ googleSearch: {} }],
                  },
                })
              );
              groundedNotes = searchRes.text || '';
            } catch {
              groundedNotes = '';
            }
          }
        }
      }

      const rawTextUrls = [
        ...extractUrlsFromText(meta.description, canonicalUrl),
        ...extractUrlsFromText(meta.captionsText, canonicalUrl),
        ...extractUrlsFromText(groundedNotes, canonicalUrl),
      ];
      const fallbackLinks: ExtractedLink[] = [
        ...meta.extractedLinks,
        ...rawTextUrls.map((u) => {
          let label = u;
          try {
            label = new URL(u).hostname.replace(/^www\./, '');
          } catch {
            // Keep URL as label
          }
          return { url: u, label, kind: 'resource' as const };
        }),
      ];

      const synthesisPrompt = [
        itemType === 'link'
          ? `Convert the following webpage/product/service metadata and content into a structured JSON Universal Share Inbox breakdown.`
          : `Convert the following verified video metadata, captions, and grounded analysis into a structured JSON breakdown.`,
        `Item Type: ${itemType}`,
        `Platform: ${platform}`,
        `Canonical URL: ${canonicalUrl}`,
        meta.title ? `Title: ${meta.title}` : '',
        meta.creator ? `Creator / Brand: ${meta.creator}` : '',
        meta.durationSeconds > 0 ? `Duration: ${formatSeconds(meta.durationSeconds)}` : '',
        meta.description ? `Description:\n${meta.description.slice(0, 2500)}` : '',
        meta.pageText ? `Webpage Text Excerpt:\n${meta.pageText.slice(0, 5000)}` : '',
        meta.captionsText ? `Timestamped Captions:\n${meta.captionsText.slice(0, 12000)}` : '',
        groundedNotes ? `Grounded Analysis Notes:\n${groundedNotes.slice(0, 12000)}` : '',
        fallbackLinks.length > 0
          ? `Discovered Candidate URLs:\n${fallbackLinks
              .slice(0, 20)
              .map((l) => `- ${l.url} (${l.label})`)
              .join('\n')}`
          : '',
        reasonContext,
        adminGuidance ? `Workspace guidance: ${adminGuidance}` : '',
        targetLanguage && targetLanguage.toLowerCase() !== 'auto-detect'
          ? `Write summary, TL;DR bullets, segment titles, and descriptions in ${targetLanguage}.`
          : '',
        `Rules:`,
        itemType === 'link'
          ? `- Organize the page highlights into 'segments' (e.g., 00:00 Overview, 00:01 Key Features / Pricing, 00:02 Details) and key specs/facts into 'transcript'.`
          : `- Keep timestamps strictly chronological and formatted MM:SS (or HH:MM:SS), covering opening, middle, and conclusion clearly.`,
        `- Retrieve and label all useful URLs, product links, service links, or tools mentioned or linked into 'links' (classify kind as product, service, resource, social, or other).`,
        `- Generate clean lowercase tags (5-10 items, no # prefix) including product/service/keyword terms for instant retrieval later.`,
        `- Do not invent fake verbatim quotes if captions/text were restricted.`,
      ]
        .filter(Boolean)
        .join('\n\n');

      const structuredRes = await generateWithRetryAndFallback((model, isFallback) =>
        ai.models.generateContent({
          model,
          contents: synthesisPrompt,
          config: {
            thinkingConfig: {
              thinkingLevel: isFallback ? ThinkingLevel.LOW : thinkingLevel,
            },
            responseMimeType: 'application/json',
            responseSchema: analysisResponseSchema,
          },
        })
      );

      const parsed = JSON.parse((structuredRes.text ?? '{}').trim()) as Record<string, unknown>;
      const normalized = normalizeAnalysisPayload(
        parsed,
        fallbackTitle,
        meta.creator || (itemType === 'link' ? new URL(canonicalUrl).hostname.replace(/^www\./, '') : 'Creator'),
        fallbackDuration,
        fallbackLinks
      );

      const responsePayload: AnalyzeVideoResponse = {
        itemType,
        url: canonicalUrl,
        platform,
        thumbnailUrl: meta.thumbnailUrl,
        metadataSource: meta.metadataSource,
        ...normalized,
      };

      guard.recordSuccess?.();
      res.json(responsePayload);
    } catch (err) {
      const { status, message } = formatGeminiError(err);
      res.status(status).json({ error: message });
    } finally {
      releaseGuard?.();
    }
  });

  app.post('/api/ask-video', async (req: Request, res: Response) => {
    let releaseGuard: (() => void) | undefined;
    try {
      const { video, question, history } = req.body as {
        video?: {
          itemType?: InboxItemType;
          title: string;
          creator: string;
          platform: string;
          summary: string;
          segments: VideoSegment[];
          transcript: TranscriptEntry[];
          links?: ExtractedLink[];
          saveReason?: string;
          notes?: string;
        };
        question?: string;
        history?: Array<{ role: 'user' | 'model'; text: string }>;
      };

      if (!video || !question?.trim()) {
        res.status(400).json({ error: 'Item context and question are required.' });
        return;
      }
      if (question.trim().length > 1000) {
        res.status(400).json({ error: 'Question is too long (max 1,000 characters).' });
        return;
      }

      const cfg = getFirebaseAppletConfig();
      const caller = await verifyCallerIdentity(req, cfg.projectId);
      const guard = guardAiRequest(caller, 'ask', res);
      if (!guard.allowed) {
        return;
      }
      releaseGuard = guard.release;

      const ai = getGeminiClient();
      const contextBlock = [
        `Item Type: ${video.itemType || 'video'}`,
        `Title: ${String(video.title || '').slice(0, 300)}`,
        `Source/Creator: ${String(video.creator || '').slice(0, 150)} (${String(video.platform || '').slice(0, 32)})`,
        video.saveReason ? `Why User Saved This: ${String(video.saveReason).slice(0, 80)}` : '',
        video.notes ? `User Notes: ${String(video.notes).slice(0, 1000)}` : '',
        `Summary: ${String(video.summary || '').slice(0, 4000)}`,
        `Segments / Sections:\n${(Array.isArray(video.segments) ? video.segments : [])
          .slice(0, 40)
          .map((s) => `[${s.timestamp}] ${String(s.title).slice(0, 140)}: ${String(s.summary).slice(0, 400)}${s.keyQuote ? ` ("${String(s.keyQuote).slice(0, 200)}")` : ''}`)
          .join('\n')}`,
        `Transcript / Extracted Text:\n${(Array.isArray(video.transcript) ? video.transcript : [])
          .slice(0, 80)
          .map((t) => `[${t.timestamp}] ${String(t.speaker || 'Speaker').slice(0, 50)}: ${String(t.text).slice(0, 400)}`)
          .join('\n')}`,
        video.links && video.links.length > 0
          ? `Retrieved Links:\n${video.links
              .slice(0, 25)
              .map((l) => `- ${String(l.label).slice(0, 140)}: ${String(l.url).slice(0, 500)}${l.context ? ` (${String(l.context).slice(0, 200)})` : ''}`)
              .join('\n')}`
          : '',
      ]
        .filter(Boolean)
        .join('\n\n');

      const historyText = (Array.isArray(history) ? history : [])
        .slice(-6)
        .map((m) => `${m.role === 'user' ? 'User' : 'Assistant'}: ${String(m.text || '').slice(0, 800)}`)
        .join('\n');

      const response = await generateWithRetryAndFallback((model) =>
        ai.models.generateContent({
          model,
          contents: `${contextBlock}\n\n${historyText ? `Conversation so far:\n${historyText}\n\n` : ''}User question: ${question.trim()}`,
          config: {
            thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
            systemInstruction:
              'You answer questions concisely using only the provided summary, segments/sections, transcript/OCR text, notes, and retrieved links. Cite relevant timestamps or section markers in square brackets like [01:24] when applicable.',
          },
        })
      );

      guard.recordSuccess?.();
      res.json({ answer: response.text || 'No response generated.' });
    } catch (err) {
      const { status, message } = formatGeminiError(err);
      res.status(status).json({ error: message });
    } finally {
      releaseGuard?.();
    }
  });

  return app;
}
